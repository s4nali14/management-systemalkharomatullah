import { api } from "encore.dev/api";
import { SQLDatabase } from "encore.dev/storage/sqldb";

const db = SQLDatabase.named("management");

export interface Finance {
  id: number;
  date: string;
  type: "Pemasukan" | "Pengeluaran";
  amount: number;
  description: string;
  source: "Donasi" | "Iuran";
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateFinanceRequest {
  date: string;
  type: "Pemasukan" | "Pengeluaran";
  amount: number;
  description: string;
  source: "Donasi" | "Iuran";
}

export interface UpdateFinanceRequest {
  id: number;
  date: string;
  type: "Pemasukan" | "Pengeluaran";
  amount: number;
  description: string;
  source: "Donasi" | "Iuran";
}

export interface ListFinancesResponse {
  finances: Finance[];
}

// Creates a new finance record.
export const createFinance = api<CreateFinanceRequest, Finance>(
  { expose: true, method: "POST", path: "/finances" },
  async (req) => {
    const now = new Date();
    const finance = await db.queryRow<Finance>`
      INSERT INTO finances (date, type, amount, description, source, created_at, updated_at)
      VALUES (${req.date}, ${req.type}, ${req.amount}, ${req.description}, ${req.source}, ${now}, ${now})
      RETURNING *
    `;
    return finance!;
  }
);

// Retrieves all finance records.
export const listFinances = api<void, ListFinancesResponse>(
  { expose: true, method: "GET", path: "/finances" },
  async () => {
    const finances = await db.queryAll<Finance>`SELECT * FROM finances ORDER BY date DESC`;
    return { finances };
  }
);

// Retrieves a specific finance record by ID.
export const getFinance = api<{ id: number }, Finance>(
  { expose: true, method: "GET", path: "/finances/:id" },
  async ({ id }) => {
    const finance = await db.queryRow<Finance>`SELECT * FROM finances WHERE id = ${id}`;
    if (!finance) {
      throw new Error("Finance record not found");
    }
    return finance;
  }
);

// Updates an existing finance record.
export const updateFinance = api<UpdateFinanceRequest, Finance>(
  { expose: true, method: "PUT", path: "/finances/:id" },
  async (req) => {
    const now = new Date();
    const finance = await db.queryRow<Finance>`
      UPDATE finances 
      SET date = ${req.date}, type = ${req.type}, amount = ${req.amount}, 
          description = ${req.description}, source = ${req.source}, updated_at = ${now}
      WHERE id = ${req.id}
      RETURNING *
    `;
    if (!finance) {
      throw new Error("Finance record not found");
    }
    return finance;
  }
);

// Deletes a finance record.
export const deleteFinance = api<{ id: number }, void>(
  { expose: true, method: "DELETE", path: "/finances/:id" },
  async ({ id }) => {
    await db.exec`DELETE FROM finances WHERE id = ${id}`;
  }
);
