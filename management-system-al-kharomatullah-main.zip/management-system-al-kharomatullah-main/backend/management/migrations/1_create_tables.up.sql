CREATE TABLE members (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  nik TEXT NOT NULL UNIQUE,
  gender TEXT NOT NULL CHECK (gender IN ('Laki-laki', 'Perempuan')),
  birth_date TEXT NOT NULL,
  address TEXT NOT NULL,
  whatsapp TEXT NOT NULL,
  photo TEXT,
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL
);

CREATE TABLE beneficiaries (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  address TEXT NOT NULL,
  description TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('Yatim', 'Piatu', 'Dhuafa', 'Lansia', 'Janda', 'Anggota', 'Keluarga Anggota')),
  nik TEXT,
  ktp_file TEXT,
  kk_file TEXT,
  category TEXT NOT NULL CHECK (category IN ('Bantuan Sosial', 'Bantuan Kesehatan', 'Bantuan Pendidikan', 'Bantuan Ekonomi', 'Bantuan Bencana', 'Lainnya')),
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL
);

CREATE TABLE activities (
  id BIGSERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  date TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('Bakti Sosial Pengobatan', 'Bantuan Sosial/Bencana', 'Santunan', 'Pertemuan Bulanan', 'Kajian', 'Pendalaman Materi', 'Rapat')),
  description TEXT NOT NULL,
  responsible TEXT,
  file TEXT,
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL
);

CREATE TABLE finances (
  id BIGSERIAL PRIMARY KEY,
  date TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('Pemasukan', 'Pengeluaran')),
  amount DOUBLE PRECISION NOT NULL,
  description TEXT NOT NULL,
  source TEXT NOT NULL CHECK (source IN ('Donasi', 'Iuran')),
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL
);

CREATE TABLE documents (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  file_name TEXT NOT NULL,
  file_size BIGINT NOT NULL,
  file_type TEXT NOT NULL,
  upload_date TIMESTAMP NOT NULL,
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL
);

CREATE TABLE letters (
  id BIGSERIAL PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  division TEXT NOT NULL CHECK (division IN ('PEM', 'KETEUM', 'SEKRE', 'HUMAS', 'KOOR')),
  type TEXT NOT NULL CHECK (type IN ('SU', 'SE', 'SKPEM', 'SK', 'SPK', 'SH', 'SST', 'SP', 'SKK', 'SI')),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  file TEXT,
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL
);
