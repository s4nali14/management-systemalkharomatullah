import { api } from "encore.dev/api";
import { SQLDatabase } from "encore.dev/storage/sqldb";

const db = SQLDatabase.named("management");

export interface Activity {
  id: number;
  title: string;
  date: string;
  type: "Bakti Sosial Pengobatan" | "Bantuan Sosial/Bencana" | "Santunan" | "Pertemuan Bulanan" | "Kajian" | "Pendalaman Materi" | "Rapat";
  description: string;
  responsible?: string;
  file?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateActivityRequest {
  title: string;
  date: string;
  type: "Bakti Sosial Pengobatan" | "Bantuan Sosial/Bencana" | "Santunan" | "Pertemuan Bulanan" | "Kajian" | "Pendalaman Materi" | "Rapat";
  description: string;
  responsible?: string;
  file?: string;
}

export interface UpdateActivityRequest {
  id: number;
  title: string;
  date: string;
  type: "Bakti Sosial Pengobatan" | "Bantuan Sosial/Bencana" | "Santunan" | "Pertemuan Bulanan" | "Kajian" | "Pendalaman Materi" | "Rapat";
  description: string;
  responsible?: string;
  file?: string;
}

export interface ListActivitiesResponse {
  activities: Activity[];
}

// Creates a new activity.
export const createActivity = api<CreateActivityRequest, Activity>(
  { expose: true, method: "POST", path: "/activities" },
  async (req) => {
    const now = new Date();
    const activity = await db.queryRow<Activity>`
      INSERT INTO activities (title, date, type, description, responsible, file, created_at, updated_at)
      VALUES (${req.title}, ${req.date}, ${req.type}, ${req.description}, ${req.responsible}, ${req.file}, ${now}, ${now})
      RETURNING *
    `;
    return activity!;
  }
);

// Retrieves all activities.
export const listActivities = api<void, ListActivitiesResponse>(
  { expose: true, method: "GET", path: "/activities" },
  async () => {
    const activities = await db.queryAll<Activity>`SELECT * FROM activities ORDER BY date DESC`;
    return { activities };
  }
);

// Retrieves a specific activity by ID.
export const getActivity = api<{ id: number }, Activity>(
  { expose: true, method: "GET", path: "/activities/:id" },
  async ({ id }) => {
    const activity = await db.queryRow<Activity>`SELECT * FROM activities WHERE id = ${id}`;
    if (!activity) {
      throw new Error("Activity not found");
    }
    return activity;
  }
);

// Updates an existing activity.
export const updateActivity = api<UpdateActivityRequest, Activity>(
  { expose: true, method: "PUT", path: "/activities/:id" },
  async (req) => {
    const now = new Date();
    const activity = await db.queryRow<Activity>`
      UPDATE activities 
      SET title = ${req.title}, date = ${req.date}, type = ${req.type}, 
          description = ${req.description}, responsible = ${req.responsible}, 
          file = ${req.file}, updated_at = ${now}
      WHERE id = ${req.id}
      RETURNING *
    `;
    if (!activity) {
      throw new Error("Activity not found");
    }
    return activity;
  }
);

// Deletes an activity.
export const deleteActivity = api<{ id: number }, void>(
  { expose: true, method: "DELETE", path: "/activities/:id" },
  async ({ id }) => {
    await db.exec`DELETE FROM activities WHERE id = ${id}`;
  }
);
