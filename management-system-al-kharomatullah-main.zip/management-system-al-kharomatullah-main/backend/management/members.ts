import { api } from "encore.dev/api";
import { SQLDatabase } from "encore.dev/storage/sqldb";

const db = new SQLDatabase("management", {
  migrations: "./migrations",
});

export interface Member {
  id: number;
  name: string;
  nik: string;
  gender: "Laki-laki" | "Perempuan";
  birthDate: string;
  address: string;
  whatsapp: string;
  photo?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateMemberRequest {
  name: string;
  nik: string;
  gender: "Laki-laki" | "Perempuan";
  birthDate: string;
  address: string;
  whatsapp: string;
  photo?: string;
}

export interface UpdateMemberRequest {
  id: number;
  name: string;
  nik: string;
  gender: "Laki-laki" | "Perempuan";
  birthDate: string;
  address: string;
  whatsapp: string;
  photo?: string;
}

export interface ListMembersResponse {
  members: Member[];
}

// Creates a new member.
export const createMember = api<CreateMemberRequest, Member>(
  { expose: true, method: "POST", path: "/members" },
  async (req) => {
    const now = new Date();
    const member = await db.queryRow<Member>`
      INSERT INTO members (name, nik, gender, birth_date, address, whatsapp, photo, created_at, updated_at)
      VALUES (${req.name}, ${req.nik}, ${req.gender}, ${req.birthDate}, ${req.address}, ${req.whatsapp}, ${req.photo}, ${now}, ${now})
      RETURNING *
    `;
    return member!;
  }
);

// Retrieves all members.
export const listMembers = api<void, ListMembersResponse>(
  { expose: true, method: "GET", path: "/members" },
  async () => {
    const members = await db.queryAll<Member>`SELECT * FROM members ORDER BY created_at DESC`;
    return { members };
  }
);

// Retrieves a specific member by ID.
export const getMember = api<{ id: number }, Member>(
  { expose: true, method: "GET", path: "/members/:id" },
  async ({ id }) => {
    const member = await db.queryRow<Member>`SELECT * FROM members WHERE id = ${id}`;
    if (!member) {
      throw new Error("Member not found");
    }
    return member;
  }
);

// Updates an existing member.
export const updateMember = api<UpdateMemberRequest, Member>(
  { expose: true, method: "PUT", path: "/members/:id" },
  async (req) => {
    const now = new Date();
    const member = await db.queryRow<Member>`
      UPDATE members 
      SET name = ${req.name}, nik = ${req.nik}, gender = ${req.gender}, 
          birth_date = ${req.birthDate}, address = ${req.address}, 
          whatsapp = ${req.whatsapp}, photo = ${req.photo}, updated_at = ${now}
      WHERE id = ${req.id}
      RETURNING *
    `;
    if (!member) {
      throw new Error("Member not found");
    }
    return member;
  }
);

// Deletes a member.
export const deleteMember = api<{ id: number }, void>(
  { expose: true, method: "DELETE", path: "/members/:id" },
  async ({ id }) => {
    await db.exec`DELETE FROM members WHERE id = ${id}`;
  }
);
