import { api } from "encore.dev/api";
import { SQLDatabase } from "encore.dev/storage/sqldb";

const db = SQLDatabase.named("management");

export interface Document {
  id: number;
  name: string;
  description: string;
  fileName: string;
  fileSize: number;
  fileType: string;
  uploadDate: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateDocumentRequest {
  name: string;
  description: string;
  fileName: string;
  fileSize: number;
  fileType: string;
}

export interface UpdateDocumentRequest {
  id: number;
  name: string;
  description: string;
}

export interface ListDocumentsResponse {
  documents: Document[];
}

// Creates a new document record.
export const createDocument = api<CreateDocumentRequest, Document>(
  { expose: true, method: "POST", path: "/documents" },
  async (req) => {
    const now = new Date();
    const document = await db.queryRow<Document>`
      INSERT INTO documents (name, description, file_name, file_size, file_type, upload_date, created_at, updated_at)
      VALUES (${req.name}, ${req.description}, ${req.fileName}, ${req.fileSize}, ${req.fileType}, ${now}, ${now}, ${now})
      RETURNING *
    `;
    return document!;
  }
);

// Retrieves all documents.
export const listDocuments = api<void, ListDocumentsResponse>(
  { expose: true, method: "GET", path: "/documents" },
  async () => {
    const documents = await db.queryAll<Document>`SELECT * FROM documents ORDER BY upload_date DESC`;
    return { documents };
  }
);

// Retrieves a specific document by ID.
export const getDocument = api<{ id: number }, Document>(
  { expose: true, method: "GET", path: "/documents/:id" },
  async ({ id }) => {
    const document = await db.queryRow<Document>`SELECT * FROM documents WHERE id = ${id}`;
    if (!document) {
      throw new Error("Document not found");
    }
    return document;
  }
);

// Updates an existing document.
export const updateDocument = api<UpdateDocumentRequest, Document>(
  { expose: true, method: "PUT", path: "/documents/:id" },
  async (req) => {
    const now = new Date();
    const document = await db.queryRow<Document>`
      UPDATE documents 
      SET name = ${req.name}, description = ${req.description}, updated_at = ${now}
      WHERE id = ${req.id}
      RETURNING *
    `;
    if (!document) {
      throw new Error("Document not found");
    }
    return document;
  }
);

// Deletes a document.
export const deleteDocument = api<{ id: number }, void>(
  { expose: true, method: "DELETE", path: "/documents/:id" },
  async ({ id }) => {
    await db.exec`DELETE FROM documents WHERE id = ${id}`;
  }
);
