import { api } from "encore.dev/api";
import { SQLDatabase } from "encore.dev/storage/sqldb";

const db = SQLDatabase.named("management");

export interface Beneficiary {
  id: number;
  name: string;
  address: string;
  description: string;
  status: "Yatim" | "Piatu" | "Dhuafa" | "Lansia" | "Janda" | "Anggota" | "Keluarga Anggota";
  nik?: string;
  ktpFile?: string;
  kkFile?: string;
  category: "Bantuan Sosial" | "Bantuan Kesehatan" | "Bantuan Pendidikan" | "Bantuan Ekonomi" | "Bantuan Bencana" | "Lainnya";
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateBeneficiaryRequest {
  name: string;
  address: string;
  description: string;
  status: "Yatim" | "Piatu" | "Dhuafa" | "Lansia" | "Janda" | "Anggota" | "Keluarga Anggota";
  nik?: string;
  ktpFile?: string;
  kkFile?: string;
  category: "Bantuan Sosial" | "Bantuan Kesehatan" | "Bantuan Pendidikan" | "Bantuan Ekonomi" | "Bantuan Bencana" | "Lainnya";
}

export interface UpdateBeneficiaryRequest {
  id: number;
  name: string;
  address: string;
  description: string;
  status: "Yatim" | "Piatu" | "Dhuafa" | "Lansia" | "Janda" | "Anggota" | "Keluarga Anggota";
  nik?: string;
  ktpFile?: string;
  kkFile?: string;
  category: "Bantuan Sosial" | "Bantuan Kesehatan" | "Bantuan Pendidikan" | "Bantuan Ekonomi" | "Bantuan Bencana" | "Lainnya";
}

export interface ListBeneficiariesResponse {
  beneficiaries: Beneficiary[];
}

// Creates a new beneficiary.
export const createBeneficiary = api<CreateBeneficiaryRequest, Beneficiary>(
  { expose: true, method: "POST", path: "/beneficiaries" },
  async (req) => {
    const now = new Date();
    const beneficiary = await db.queryRow<Beneficiary>`
      INSERT INTO beneficiaries (name, address, description, status, nik, ktp_file, kk_file, category, created_at, updated_at)
      VALUES (${req.name}, ${req.address}, ${req.description}, ${req.status}, ${req.nik}, ${req.ktpFile}, ${req.kkFile}, ${req.category}, ${now}, ${now})
      RETURNING *
    `;
    return beneficiary!;
  }
);

// Retrieves all beneficiaries.
export const listBeneficiaries = api<void, ListBeneficiariesResponse>(
  { expose: true, method: "GET", path: "/beneficiaries" },
  async () => {
    const beneficiaries = await db.queryAll<Beneficiary>`SELECT * FROM beneficiaries ORDER BY created_at DESC`;
    return { beneficiaries };
  }
);

// Retrieves a specific beneficiary by ID.
export const getBeneficiary = api<{ id: number }, Beneficiary>(
  { expose: true, method: "GET", path: "/beneficiaries/:id" },
  async ({ id }) => {
    const beneficiary = await db.queryRow<Beneficiary>`SELECT * FROM beneficiaries WHERE id = ${id}`;
    if (!beneficiary) {
      throw new Error("Beneficiary not found");
    }
    return beneficiary;
  }
);

// Updates an existing beneficiary.
export const updateBeneficiary = api<UpdateBeneficiaryRequest, Beneficiary>(
  { expose: true, method: "PUT", path: "/beneficiaries/:id" },
  async (req) => {
    const now = new Date();
    const beneficiary = await db.queryRow<Beneficiary>`
      UPDATE beneficiaries 
      SET name = ${req.name}, address = ${req.address}, description = ${req.description}, 
          status = ${req.status}, nik = ${req.nik}, ktp_file = ${req.ktpFile}, 
          kk_file = ${req.kkFile}, category = ${req.category}, updated_at = ${now}
      WHERE id = ${req.id}
      RETURNING *
    `;
    if (!beneficiary) {
      throw new Error("Beneficiary not found");
    }
    return beneficiary;
  }
);

// Deletes a beneficiary.
export const deleteBeneficiary = api<{ id: number }, void>(
  { expose: true, method: "DELETE", path: "/beneficiaries/:id" },
  async ({ id }) => {
    await db.exec`DELETE FROM beneficiaries WHERE id = ${id}`;
  }
);
