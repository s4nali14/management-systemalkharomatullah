import { api } from "encore.dev/api";
import { SQLDatabase } from "encore.dev/storage/sqldb";

const db = SQLDatabase.named("management");

export interface Letter {
  id: number;
  number: string;
  division: "PEM" | "KETEUM" | "SEKRE" | "HUMAS" | "KOOR";
  type: "SU" | "SE" | "SKPEM" | "SK" | "SPK" | "SH" | "SST" | "SP" | "SKK" | "SI";
  title: string;
  description: string;
  file?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateLetterRequest {
  division: "PEM" | "KETEUM" | "SEKRE" | "HUMAS" | "KOOR";
  type: "SU" | "SE" | "SKPEM" | "SK" | "SPK" | "SH" | "SST" | "SP" | "SKK" | "SI";
  title: string;
  description: string;
  file?: string;
}

export interface UpdateLetterRequest {
  id: number;
  title: string;
  description: string;
  file?: string;
}

export interface ListLettersResponse {
  letters: Letter[];
}

export interface GenerateLetterNumberRequest {
  division: "PEM" | "KETEUM" | "SEKRE" | "HUMAS" | "KOOR";
  type: "SU" | "SE" | "SKPEM" | "SK" | "SPK" | "SH" | "SST" | "SP" | "SKK" | "SI";
}

export interface GenerateLetterNumberResponse {
  number: string;
}

// Generates a new letter number.
export const generateLetterNumber = api<GenerateLetterNumberRequest, GenerateLetterNumberResponse>(
  { expose: true, method: "POST", path: "/letters/generate-number" },
  async (req) => {
    const now = new Date();
    const month = now.getMonth() + 1;
    const year = now.getFullYear();
    
    const romanMonths = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];
    const romanMonth = romanMonths[month - 1];
    
    // Get the count of letters for this division and type in current month/year
    const count = await db.queryRow<{ count: number }>`
      SELECT COUNT(*) as count FROM letters 
      WHERE division = ${req.division} 
      AND type = ${req.type} 
      AND EXTRACT(MONTH FROM created_at) = ${month}
      AND EXTRACT(YEAR FROM created_at) = ${year}
    `;
    
    const nextNumber = (count?.count || 0) + 1;
    const paddedNumber = nextNumber.toString().padStart(3, '0');
    const letterNumber = `${paddedNumber}/${req.division}-${req.type}/${romanMonth}.${year}`;
    
    return { number: letterNumber };
  }
);

// Creates a new letter.
export const createLetter = api<CreateLetterRequest, Letter>(
  { expose: true, method: "POST", path: "/letters" },
  async (req) => {
    const now = new Date();
    const month = now.getMonth() + 1;
    const year = now.getFullYear();
    
    const romanMonths = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];
    const romanMonth = romanMonths[month - 1];
    
    // Get the count of letters for this division and type in current month/year
    const count = await db.queryRow<{ count: number }>`
      SELECT COUNT(*) as count FROM letters 
      WHERE division = ${req.division} 
      AND type = ${req.type} 
      AND EXTRACT(MONTH FROM created_at) = ${month}
      AND EXTRACT(YEAR FROM created_at) = ${year}
    `;
    
    const nextNumber = (count?.count || 0) + 1;
    const paddedNumber = nextNumber.toString().padStart(3, '0');
    const letterNumber = `${paddedNumber}/${req.division}-${req.type}/${romanMonth}.${year}`;
    
    const letter = await db.queryRow<Letter>`
      INSERT INTO letters (number, division, type, title, description, file, created_at, updated_at)
      VALUES (${letterNumber}, ${req.division}, ${req.type}, ${req.title}, ${req.description}, ${req.file}, ${now}, ${now})
      RETURNING *
    `;
    return letter!;
  }
);

// Retrieves all letters.
export const listLetters = api<void, ListLettersResponse>(
  { expose: true, method: "GET", path: "/letters" },
  async () => {
    const letters = await db.queryAll<Letter>`SELECT * FROM letters ORDER BY created_at DESC`;
    return { letters };
  }
);

// Retrieves a specific letter by ID.
export const getLetter = api<{ id: number }, Letter>(
  { expose: true, method: "GET", path: "/letters/:id" },
  async ({ id }) => {
    const letter = await db.queryRow<Letter>`SELECT * FROM letters WHERE id = ${id}`;
    if (!letter) {
      throw new Error("Letter not found");
    }
    return letter;
  }
);

// Updates an existing letter.
export const updateLetter = api<UpdateLetterRequest, Letter>(
  { expose: true, method: "PUT", path: "/letters/:id" },
  async (req) => {
    const now = new Date();
    const letter = await db.queryRow<Letter>`
      UPDATE letters 
      SET title = ${req.title}, description = ${req.description}, file = ${req.file}, updated_at = ${now}
      WHERE id = ${req.id}
      RETURNING *
    `;
    if (!letter) {
      throw new Error("Letter not found");
    }
    return letter;
  }
);

// Deletes a letter.
export const deleteLetter = api<{ id: number }, void>(
  { expose: true, method: "DELETE", path: "/letters/:id" },
  async ({ id }) => {
    await db.exec`DELETE FROM letters WHERE id = ${id}`;
  }
);
