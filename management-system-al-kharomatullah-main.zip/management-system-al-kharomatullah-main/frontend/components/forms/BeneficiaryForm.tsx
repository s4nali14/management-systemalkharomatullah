import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { X, Upload } from 'lucide-react';

interface Beneficiary {
  id: string;
  name: string;
  address: string;
  description: string;
  status: 'Yatim' | 'Piatu' | 'Dhuafa' | 'Lansia' | 'Janda' | 'Anggota' | 'Keluarga Anggota';
  nik?: string;
  ktpFile?: string;
  kkFile?: string;
  category: 'Bantuan Sosial' | 'Bantuan Kesehatan' | 'Bantuan Pendidikan' | 'Bantuan Ekonomi' | 'Bantuan Bencana' | 'Lainnya';
  createdAt: string;
}

interface BeneficiaryFormProps {
  beneficiary?: Beneficiary | null;
  onSave: (beneficiary: Omit<Beneficiary, 'id' | 'createdAt'>) => void;
  onCancel: () => void;
}

export function BeneficiaryForm({ beneficiary, onSave, onCancel }: BeneficiaryFormProps) {
  const [formData, setFormData] = useState({
    name: beneficiary?.name || '',
    address: beneficiary?.address || '',
    description: beneficiary?.description || '',
    status: beneficiary?.status || 'Yatim' as 'Yatim' | 'Piatu' | 'Dhuafa' | 'Lansia' | 'Janda' | 'Anggota' | 'Keluarga Anggota',
    nik: beneficiary?.nik || '',
    ktpFile: beneficiary?.ktpFile || '',
    kkFile: beneficiary?.kkFile || '',
    category: beneficiary?.category || 'Bantuan Sosial' as 'Bantuan Sosial' | 'Bantuan Kesehatan' | 'Bantuan Pendidikan' | 'Bantuan Ekonomi' | 'Bantuan Bencana' | 'Lainnya',
  });

  const ktpFileInputRef = useRef<HTMLInputElement>(null);
  const kkFileInputRef = useRef<HTMLInputElement>(null);

  const statusesRequiringDocuments = ['Yatim', 'Piatu', 'Dhuafa', 'Lansia', 'Janda'];
  const showDocumentFields = statusesRequiringDocuments.includes(formData.status);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileUpload = (field: 'ktpFile' | 'kkFile', event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setFormData(prev => ({ ...prev, [field]: e.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>{beneficiary ? 'Edit Penerima Manfaat' : 'Tambah Penerima Manfaat Baru'}</CardTitle>
          <Button variant="ghost" size="sm" onClick={onCancel}>
            <X size={16} />
          </Button>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nama Lengkap *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status *</Label>
                <Select value={formData.status} onValueChange={(value) => handleInputChange('status', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Yatim">Yatim</SelectItem>
                    <SelectItem value="Piatu">Piatu</SelectItem>
                    <SelectItem value="Dhuafa">Dhuafa</SelectItem>
                    <SelectItem value="Lansia">Lansia</SelectItem>
                    <SelectItem value="Janda">Janda</SelectItem>
                    <SelectItem value="Anggota">Anggota</SelectItem>
                    <SelectItem value="Keluarga Anggota">Keluarga Anggota</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Kategori Bantuan *</Label>
                <Select value={formData.category} onValueChange={(value) => handleInputChange('category', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Bantuan Sosial">Bantuan Sosial</SelectItem>
                    <SelectItem value="Bantuan Kesehatan">Bantuan Kesehatan</SelectItem>
                    <SelectItem value="Bantuan Pendidikan">Bantuan Pendidikan</SelectItem>
                    <SelectItem value="Bantuan Ekonomi">Bantuan Ekonomi</SelectItem>
                    <SelectItem value="Bantuan Bencana">Bantuan Bencana</SelectItem>
                    <SelectItem value="Lainnya">Lainnya</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {showDocumentFields && (
                <div className="space-y-2">
                  <Label htmlFor="nik">NIK *</Label>
                  <Input
                    id="nik"
                    value={formData.nik}
                    onChange={(e) => handleInputChange('nik', e.target.value)}
                    maxLength={16}
                    required={showDocumentFields}
                  />
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Alamat Lengkap *</Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                rows={3}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Keterangan *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={3}
                required
              />
            </div>

            {showDocumentFields && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="ktpFile">Upload KTP</Label>
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => ktpFileInputRef.current?.click()}
                      className="flex items-center gap-2"
                    >
                      <Upload size={16} />
                      Upload KTP
                    </Button>
                    <input
                      ref={ktpFileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload('ktpFile', e)}
                      className="hidden"
                    />
                  </div>
                  {formData.ktpFile && (
                    <div className="mt-2">
                      <img
                        src={formData.ktpFile}
                        alt="KTP Preview"
                        className="w-32 h-20 object-cover border rounded"
                      />
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="kkFile">Upload KK</Label>
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => kkFileInputRef.current?.click()}
                      className="flex items-center gap-2"
                    >
                      <Upload size={16} />
                      Upload KK
                    </Button>
                    <input
                      ref={kkFileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload('kkFile', e)}
                      className="hidden"
                    />
                  </div>
                  {formData.kkFile && (
                    <div className="mt-2">
                      <img
                        src={formData.kkFile}
                        alt="KK Preview"
                        className="w-32 h-20 object-cover border rounded"
                      />
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="outline" onClick={onCancel}>
                Batal
              </Button>
              <Button type="submit">
                {beneficiary ? 'Perbarui' : 'Simpan'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
