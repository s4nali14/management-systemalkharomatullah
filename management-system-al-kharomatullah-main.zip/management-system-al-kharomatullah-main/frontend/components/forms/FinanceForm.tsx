import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { X } from 'lucide-react';

interface Finance {
  id: string;
  date: string;
  type: 'Pemasukan' | 'Pengeluaran';
  amount: number;
  description: string;
  source: 'Saldo Awal' | 'Dana Santunan' | 'Dana Baksos Pengobatan' | 'Dana Sosial' | 'Zakat' | 'Infaq' | 'Iuran Anggota' | 'Lainnya';
  createdAt: string;
}

interface FinanceFormProps {
  finance?: Finance | null;
  onSave: (finance: Omit<Finance, 'id' | 'createdAt'>) => void;
  onCancel: () => void;
}

export function FinanceForm({ finance, onSave, onCancel }: FinanceFormProps) {
  const [formData, setFormData] = useState({
    date: finance?.date || new Date().toISOString().split('T')[0],
    type: finance?.type || 'Pemasukan' as 'Pemasukan' | 'Pengeluaran',
    amount: finance?.amount || 0,
    description: finance?.description || '',
    source: finance?.source || 'Iuran Anggota' as 'Saldo Awal' | 'Dana Santunan' | 'Dana Baksos Pengobatan' | 'Dana Sosial' | 'Zakat' | 'Infaq' | 'Iuran Anggota' | 'Lainnya',
  });

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const getSourceOptions = () => {
    if (formData.type === 'Pemasukan') {
      return [
        { value: 'Saldo Awal', label: 'Saldo Awal' },
        { value: 'Dana Santunan', label: 'Dana Santunan' },
        { value: 'Dana Baksos Pengobatan', label: 'Dana Baksos Pengobatan' },
        { value: 'Dana Sosial', label: 'Dana Sosial' },
        { value: 'Zakat', label: 'Zakat' },
        { value: 'Infaq', label: 'Infaq' },
        { value: 'Iuran Anggota', label: 'Iuran Anggota' },
        { value: 'Lainnya', label: 'Lainnya' },
      ];
    } else {
      return [
        { value: 'Dana Santunan', label: 'Dana Santunan' },
        { value: 'Dana Baksos Pengobatan', label: 'Dana Baksos Pengobatan' },
        { value: 'Dana Sosial', label: 'Dana Sosial' },
        { value: 'Operasional', label: 'Operasional' },
        { value: 'Lainnya', label: 'Lainnya' },
      ];
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>{finance ? 'Edit Transaksi' : 'Tambah Transaksi Baru'}</CardTitle>
          <Button variant="ghost" size="sm" onClick={onCancel}>
            <X size={16} />
          </Button>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date">Tanggal *</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => handleInputChange('date', e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Jenis Transaksi *</Label>
                <Select value={formData.type} onValueChange={(value) => {
                  handleInputChange('type', value);
                  // Reset source when type changes
                  if (value === 'Pemasukan') {
                    handleInputChange('source', 'Iuran Anggota');
                  } else {
                    handleInputChange('source', 'Operasional');
                  }
                }}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Pemasukan">Pemasukan</SelectItem>
                    <SelectItem value="Pengeluaran">Pengeluaran</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">Jumlah *</Label>
                <Input
                  id="amount"
                  type="number"
                  min="0"
                  step="1000"
                  value={formData.amount}
                  onChange={(e) => handleInputChange('amount', parseFloat(e.target.value) || 0)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="source">
                  {formData.type === 'Pemasukan' ? 'Sumber Dana *' : 'Kategori Pengeluaran *'}
                </Label>
                <Select value={formData.source} onValueChange={(value) => handleInputChange('source', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {getSourceOptions().map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Keterangan *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={3}
                required
              />
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="outline" onClick={onCancel}>
                Batal
              </Button>
              <Button type="submit">
                {finance ? 'Perbarui' : 'Simpan'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
