import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { X, Upload, Users } from 'lucide-react';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface Member {
  id: string;
  name: string;
  nik: string;
  gender: 'Laki-laki' | 'Perempuan';
  birthDate: string;
  address: string;
  whatsapp: string;
  photo?: string;
  createdAt: string;
}

interface AttendanceRecord {
  memberId: string;
  memberName: string;
  status: 'Hadir' | 'Izin' | 'Sakit' | 'Alfa';
}

interface Activity {
  id: string;
  title: string;
  date: string;
  type: 'Bakti Sosial Pengobatan' | 'Bantuan Sosial/Bencana' | 'Santunan' | 'Pertemuan Bulanan' | 'Kajian' | 'Pendalaman Materi' | 'Rapat';
  description: string;
  responsible?: string;
  file?: string;
  attendance?: AttendanceRecord[];
  createdAt: string;
}

interface ActivityFormProps {
  activity?: Activity | null;
  onSave: (activity: Omit<Activity, 'id' | 'createdAt'>) => void;
  onCancel: () => void;
}

export function ActivityForm({ activity, onSave, onCancel }: ActivityFormProps) {
  const [members] = useLocalStorage<Member[]>('members', []);
  const [showAttendance, setShowAttendance] = useState(false);
  
  const [formData, setFormData] = useState({
    title: activity?.title || '',
    date: activity?.date || '',
    type: activity?.type || 'Kajian' as 'Bakti Sosial Pengobatan' | 'Bantuan Sosial/Bencana' | 'Santunan' | 'Pertemuan Bulanan' | 'Kajian' | 'Pendalaman Materi' | 'Rapat',
    description: activity?.description || '',
    responsible: activity?.responsible || '',
    file: activity?.file || '',
    attendance: activity?.attendance || members.map(member => ({
      memberId: member.id,
      memberName: member.name,
      status: 'Hadir' as 'Hadir' | 'Izin' | 'Sakit' | 'Alfa'
    }))
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const typesRequiringResponsible = ['Bakti Sosial Pengobatan', 'Bantuan Sosial/Bencana', 'Santunan', 'Pertemuan Bulanan'];
  const showResponsibleField = typesRequiringResponsible.includes(formData.type);

  // Update attendance when members change
  React.useEffect(() => {
    if (!activity) {
      setFormData(prev => ({
        ...prev,
        attendance: members.map(member => {
          const existingAttendance = prev.attendance?.find(a => a.memberId === member.id);
          return existingAttendance || {
            memberId: member.id,
            memberName: member.name,
            status: 'Hadir' as 'Hadir' | 'Izin' | 'Sakit' | 'Alfa'
          };
        })
      }));
    }
  }, [members, activity]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAttendanceChange = (memberId: string, status: 'Hadir' | 'Izin' | 'Sakit' | 'Alfa') => {
    setFormData(prev => ({
      ...prev,
      attendance: prev.attendance?.map(record =>
        record.memberId === memberId ? { ...record, status } : record
      ) || []
    }));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setFormData(prev => ({ ...prev, file: e.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const getAttendanceStats = () => {
    if (!formData.attendance) return { hadir: 0, izin: 0, sakit: 0, alfa: 0, total: 0 };
    
    const hadir = formData.attendance.filter(a => a.status === 'Hadir').length;
    const izin = formData.attendance.filter(a => a.status === 'Izin').length;
    const sakit = formData.attendance.filter(a => a.status === 'Sakit').length;
    const alfa = formData.attendance.filter(a => a.status === 'Alfa').length;
    const total = formData.attendance.length;
    
    return { hadir, izin, sakit, alfa, total };
  };

  const stats = getAttendanceStats();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>{activity ? 'Edit Kegiatan' : 'Tambah Kegiatan Baru'}</CardTitle>
          <Button variant="ghost" size="sm" onClick={onCancel}>
            <X size={16} />
          </Button>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Judul Kegiatan *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="date">Tanggal *</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => handleInputChange('date', e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Jenis Kegiatan *</Label>
                <Select value={formData.type} onValueChange={(value) => handleInputChange('type', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Bakti Sosial Pengobatan">Bakti Sosial Pengobatan</SelectItem>
                    <SelectItem value="Bantuan Sosial/Bencana">Bantuan Sosial/Bencana</SelectItem>
                    <SelectItem value="Santunan">Santunan</SelectItem>
                    <SelectItem value="Pertemuan Bulanan">Pertemuan Bulanan</SelectItem>
                    <SelectItem value="Kajian">Kajian</SelectItem>
                    <SelectItem value="Pendalaman Materi">Pendalaman Materi</SelectItem>
                    <SelectItem value="Rapat">Rapat</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {showResponsibleField && (
                <div className="space-y-2">
                  <Label htmlFor="responsible">Penanggung Jawab *</Label>
                  <Input
                    id="responsible"
                    value={formData.responsible}
                    onChange={(e) => handleInputChange('responsible', e.target.value)}
                    required={showResponsibleField}
                  />
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Deskripsi Kegiatan *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={4}
                required
              />
            </div>

            {showResponsibleField && (
              <div className="space-y-2">
                <Label htmlFor="file">Import File</Label>
                <div className="flex items-center gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2"
                  >
                    <Upload size={16} />
                    Upload File
                  </Button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>
                {formData.file && (
                  <div className="mt-2 p-2 bg-gray-50 rounded border">
                    <p className="text-sm text-gray-600">File berhasil diupload</p>
                  </div>
                )}
              </div>
            )}

            {/* Attendance Section */}
            <div className="space-y-4 border-t pt-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Users size={20} className="text-blue-600" />
                  <Label className="text-lg font-medium">Absensi Anggota</Label>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowAttendance(!showAttendance)}
                  className="flex items-center gap-2"
                >
                  {showAttendance ? 'Sembunyikan' : 'Tampilkan'} Absensi
                </Button>
              </div>

              {/* Attendance Stats */}
              <div className="grid grid-cols-5 gap-3">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-xl font-bold text-blue-600">{stats.total}</div>
                  <p className="text-xs text-blue-600">Total</p>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="text-xl font-bold text-green-600">{stats.hadir}</div>
                  <p className="text-xs text-green-600">Hadir</p>
                </div>
                <div className="text-center p-3 bg-yellow-50 rounded-lg">
                  <div className="text-xl font-bold text-yellow-600">{stats.izin}</div>
                  <p className="text-xs text-yellow-600">Izin</p>
                </div>
                <div className="text-center p-3 bg-red-50 rounded-lg">
                  <div className="text-xl font-bold text-red-600">{stats.sakit}</div>
                  <p className="text-xs text-red-600">Sakit</p>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-xl font-bold text-gray-600">{stats.alfa}</div>
                  <p className="text-xs text-gray-600">Alfa</p>
                </div>
              </div>

              {showAttendance && (
                <div className="space-y-2">
                  <div className="max-h-60 overflow-y-auto border rounded-lg">
                    <table className="w-full">
                      <thead className="bg-gray-50 sticky top-0">
                        <tr>
                          <th className="text-left p-3 font-medium">Nama Anggota</th>
                          <th className="text-left p-3 font-medium">Status Kehadiran</th>
                        </tr>
                      </thead>
                      <tbody>
                        {formData.attendance?.map((record) => (
                          <tr key={record.memberId} className="border-t hover:bg-gray-50">
                            <td className="p-3">{record.memberName}</td>
                            <td className="p-3">
                              <Select
                                value={record.status}
                                onValueChange={(value: 'Hadir' | 'Izin' | 'Sakit' | 'Alfa') =>
                                  handleAttendanceChange(record.memberId, value)
                                }
                              >
                                <SelectTrigger className="w-32">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="Hadir">Hadir</SelectItem>
                                  <SelectItem value="Izin">Izin</SelectItem>
                                  <SelectItem value="Sakit">Sakit</SelectItem>
                                  <SelectItem value="Alfa">Alfa</SelectItem>
                                </SelectContent>
                              </Select>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  
                  {members.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      Belum ada data anggota. Tambahkan anggota terlebih dahulu untuk mengatur absensi.
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="outline" onClick={onCancel}>
                Batal
              </Button>
              <Button type="submit">
                {activity ? 'Perbarui' : 'Simpan'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
