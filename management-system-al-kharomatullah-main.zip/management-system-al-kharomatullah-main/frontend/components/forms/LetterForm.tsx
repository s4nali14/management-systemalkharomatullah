import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { X, Upload } from 'lucide-react';

interface Letter {
  id: string;
  number: string;
  division: 'PEM' | 'KETEUM' | 'SEKRE' | 'HUMAS' | 'KOOR';
  type: 'SU' | 'SE' | 'SKPEM' | 'SK' | 'SPK' | 'SH' | 'SST' | 'SP' | 'SKK' | 'SI';
  title: string;
  description: string;
  file?: string;
  createdAt: string;
}

interface LetterFormProps {
  letter?: Letter | null;
  letters: Letter[];
  onSave: (letter: Omit<Letter, 'id' | 'createdAt'>) => void;
  onCancel: () => void;
}

export function LetterForm({ letter, letters, onSave, onCancel }: LetterFormProps) {
  const [formData, setFormData] = useState({
    number: letter?.number || '',
    division: letter?.division || 'PEM' as 'PEM' | 'KETEUM' | 'SEKRE' | 'HUMAS' | 'KOOR',
    type: letter?.type || 'SU' as 'SU' | 'SE' | 'SKPEM' | 'SK' | 'SPK' | 'SH' | 'SST' | 'SP' | 'SKK' | 'SI',
    title: letter?.title || '',
    description: letter?.description || '',
    file: letter?.file || '',
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const generateNumber = () => {
    const now = new Date();
    const month = now.getMonth() + 1;
    const year = now.getFullYear();
    
    const romanMonths = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];
    const romanMonth = romanMonths[month - 1];
    
    // Get the count of letters for this division and type in current month/year
    const count = letters.filter(l => {
      if (letter && l.id === letter.id) return false; // Exclude current letter if editing
      const letterDate = new Date(l.createdAt);
      return l.division === formData.division && 
             l.type === formData.type && 
             letterDate.getMonth() + 1 === month &&
             letterDate.getFullYear() === year;
    }).length;
    
    const nextNumber = count + 1;
    const paddedNumber = nextNumber.toString().padStart(3, '0');
    const letterNumber = `${paddedNumber}/${formData.division}-${formData.type}/${romanMonth}.${year}`;
    
    setFormData(prev => ({ ...prev, number: letterNumber }));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setFormData(prev => ({ ...prev, file: e.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>{letter ? 'Edit Surat' : 'Tambah Surat Baru'}</CardTitle>
          <Button variant="ghost" size="sm" onClick={onCancel}>
            <X size={16} />
          </Button>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="division">Divisi *</Label>
                <Select value={formData.division} onValueChange={(value) => handleInputChange('division', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PEM">Pembina (PEM)</SelectItem>
                    <SelectItem value="KETEUM">Ketua Umum (KETEUM)</SelectItem>
                    <SelectItem value="SEKRE">Sekretaris (SEKRE)</SelectItem>
                    <SelectItem value="HUMAS">Humas (HUMAS)</SelectItem>
                    <SelectItem value="KOOR">Koordinator (KOOR)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Jenis Surat *</Label>
                <Select value={formData.type} onValueChange={(value) => handleInputChange('type', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SU">Surat Undangan (SU)</SelectItem>
                    <SelectItem value="SE">Surat Edaran (SE)</SelectItem>
                    <SelectItem value="SKPEM">Surat Keputusan Pembina (SKPEM)</SelectItem>
                    <SelectItem value="SK">Surat Keputusan (SK)</SelectItem>
                    <SelectItem value="SPK">Surat Perintah Kerja (SPK)</SelectItem>
                    <SelectItem value="SH">Surat Himbauan (SH)</SelectItem>
                    <SelectItem value="SST">Surat Serah Terima (SST)</SelectItem>
                    <SelectItem value="SP">Surat Peringatan (SP)</SelectItem>
                    <SelectItem value="SKK">Surat Keterangan Kerja (SKK)</SelectItem>
                    <SelectItem value="SI">Surat Izin (SI)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="number">Nomor Surat *</Label>
              <div className="flex gap-2">
                <Input
                  id="number"
                  value={formData.number}
                  onChange={(e) => handleInputChange('number', e.target.value)}
                  placeholder="001/PEM-SU/VII.2025"
                  required
                  className="flex-1"
                />
                <Button type="button" variant="outline" onClick={generateNumber}>
                  Auto Generate
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">Judul Surat *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Deskripsi *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={4}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="file">Upload File Surat</Label>
              <div className="flex items-center gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-2"
                >
                  <Upload size={16} />
                  Upload File
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>
              {formData.file && (
                <div className="mt-2 p-2 bg-gray-50 rounded border">
                  <p className="text-sm text-gray-600">File berhasil diupload</p>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="outline" onClick={onCancel}>
                Batal
              </Button>
              <Button type="submit">
                {letter ? 'Perbarui' : 'Simpan'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
