import React, { useEffect, useState } from 'react';
import { User, Heart, Calendar, DollarSign, TrendingUp, TrendingDown, CheckCircle, Clock, AlertCircle, UserCheck, UserX, UserMinus } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useLocalStorage } from '../hooks/useLocalStorage';

interface DashboardStats {
  totalMembers: number;
  totalBeneficiaries: number;
  totalActivities: number;
  totalIncome: number;
  totalExpense: number;
  balance: number;
}

interface AttendanceRecord {
  memberId: string;
  memberName: string;
  status: 'Hadir' | 'Izin' | 'Sakit' | 'Alfa';
}

interface Activity {
  id: string;
  title: string;
  date: string;
  type: string;
  description: string;
  responsible?: string;
  file?: string;
  attendance?: AttendanceRecord[];
  createdAt: string;
}

export function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalMembers: 0,
    totalBeneficiaries: 0,
    totalActivities: 0,
    totalIncome: 0,
    totalExpense: 0,
    balance: 0,
  });

  const [members] = useLocalStorage('members', []);
  const [beneficiaries] = useLocalStorage('beneficiaries', []);
  const [activities] = useLocalStorage<Activity[]>('activities', []);
  const [finances] = useLocalStorage('finances', []);

  useEffect(() => {
    const totalIncome = finances
      .filter((f: any) => f.type === 'Pemasukan')
      .reduce((sum: number, f: any) => sum + f.amount, 0);
    
    const totalExpense = finances
      .filter((f: any) => f.type === 'Pengeluaran')
      .reduce((sum: number, f: any) => sum + f.amount, 0);

    setStats({
      totalMembers: members.length,
      totalBeneficiaries: beneficiaries.length,
      totalActivities: activities.length,
      totalIncome,
      totalExpense,
      balance: totalIncome - totalExpense,
    });
  }, [members, beneficiaries, activities, finances]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
    }).format(amount);
  };

  // Get upcoming activities (next 7 days)
  const getUpcomingActivities = () => {
    const today = new Date();
    const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
    
    return activities.filter(activity => {
      const activityDate = new Date(activity.date);
      return activityDate >= today && activityDate <= nextWeek;
    }).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  };

  // Get recent activities (last 30 days)
  const getRecentActivities = () => {
    const today = new Date();
    const lastMonth = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
    
    return activities.filter(activity => {
      const activityDate = new Date(activity.date);
      return activityDate >= lastMonth && activityDate <= today;
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  // Calculate attendance progress from actual attendance data
  const getAttendanceProgress = () => {
    const recentActivities = getRecentActivities();
    const totalMembers = stats.totalMembers;
    
    if (totalMembers === 0 || recentActivities.length === 0) {
      return {
        averageAttendance: 0,
        totalActivitiesWithAttendance: 0,
        attendanceRate: 0,
        detailedStats: { hadir: 0, izin: 0, sakit: 0, alfa: 0 }
      };
    }

    // Calculate actual attendance from activities with attendance data
    const activitiesWithAttendance = recentActivities.filter(activity => activity.attendance && activity.attendance.length > 0);
    
    if (activitiesWithAttendance.length === 0) {
      return {
        averageAttendance: 0,
        totalActivitiesWithAttendance: 0,
        attendanceRate: 0,
        detailedStats: { hadir: 0, izin: 0, sakit: 0, alfa: 0 }
      };
    }

    // Calculate average attendance rate and detailed statistics
    let totalHadir = 0;
    let totalIzin = 0;
    let totalSakit = 0;
    let totalAlfa = 0;
    let totalRecords = 0;

    activitiesWithAttendance.forEach(activity => {
      const attendanceData = activity.attendance!;
      totalHadir += attendanceData.filter(record => record.status === 'Hadir').length;
      totalIzin += attendanceData.filter(record => record.status === 'Izin').length;
      totalSakit += attendanceData.filter(record => record.status === 'Sakit').length;
      totalAlfa += attendanceData.filter(record => record.status === 'Alfa').length;
      totalRecords += attendanceData.length;
    });

    const averageAttendanceRate = totalRecords > 0 ? Math.round((totalHadir / totalRecords) * 100) : 0;
    const averageAttendance = Math.round(totalHadir / activitiesWithAttendance.length);
    
    return {
      averageAttendance,
      totalActivitiesWithAttendance: activitiesWithAttendance.length,
      attendanceRate: averageAttendanceRate,
      detailedStats: {
        hadir: Math.round(totalHadir / activitiesWithAttendance.length),
        izin: Math.round(totalIzin / activitiesWithAttendance.length),
        sakit: Math.round(totalSakit / activitiesWithAttendance.length),
        alfa: Math.round(totalAlfa / activitiesWithAttendance.length)
      }
    };
  };

  const upcomingActivities = getUpcomingActivities();
  const recentActivities = getRecentActivities();
  const attendanceProgress = getAttendanceProgress();

  const getActivityTypeColor = (type: string) => {
    const colors = {
      'Bakti Sosial Pengobatan': 'text-blue-600',
      'Bantuan Sosial/Bencana': 'text-red-600',
      'Santunan': 'text-green-600',
      'Pertemuan Bulanan': 'text-purple-600',
      'Kajian': 'text-orange-600',
      'Pendalaman Materi': 'text-teal-600',
      'Rapat': 'text-gray-600',
    };
    return colors[type as keyof typeof colors] || 'text-gray-600';
  };

  const getActivityAttendanceRate = (activity: Activity) => {
    if (!activity.attendance || activity.attendance.length === 0) return null;
    
    const presentCount = activity.attendance.filter(record => record.status === 'Hadir').length;
    const totalCount = activity.attendance.length;
    return Math.round((presentCount / totalCount) * 100);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Selamat datang di Management System Al Kharomatullah</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Anggota</CardTitle>
            <User className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalMembers}</div>
            <p className="text-xs text-muted-foreground">
              Anggota terdaftar
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Penerima Manfaat</CardTitle>
            <Heart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalBeneficiaries}</div>
            <p className="text-xs text-muted-foreground">
              Penerima bantuan
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Kegiatan</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalActivities}</div>
            <p className="text-xs text-muted-foreground">
              Kegiatan terjadwal
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Saldo</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${stats.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(stats.balance)}
            </div>
            <p className="text-xs text-muted-foreground">
              Saldo saat ini
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="mr-2 h-5 w-5 text-green-600" />
              Total Pemasukan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">
              {formatCurrency(stats.totalIncome)}
            </div>
            <p className="text-sm text-gray-600 mt-2">
              Dari donasi dan iuran anggota
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingDown className="mr-2 h-5 w-5 text-red-600" />
              Total Pengeluaran
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">
              {formatCurrency(stats.totalExpense)}
            </div>
            <p className="text-sm text-gray-600 mt-2">
              Untuk operasional dan bantuan
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="mr-2 h-5 w-5 text-blue-600" />
              Kegiatan Mendatang
            </CardTitle>
          </CardHeader>
          <CardContent>
            {upcomingActivities.length > 0 ? (
              <div className="space-y-3">
                {upcomingActivities.slice(0, 5).map((activity) => {
                  const attendanceRate = getActivityAttendanceRate(activity);
                  return (
                    <div key={activity.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex-1">
                        <h4 className="font-medium text-sm">{activity.title}</h4>
                        <p className={`text-xs ${getActivityTypeColor(activity.type)}`}>
                          {activity.type}
                        </p>
                        {attendanceRate !== null && (
                          <p className="text-xs text-gray-500 mt-1">
                            Kehadiran: {attendanceRate}%
                          </p>
                        )}
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">
                          {new Date(activity.date).toLocaleDateString('id-ID', { 
                            day: 'numeric', 
                            month: 'short' 
                          })}
                        </p>
                        <div className="flex items-center text-xs text-gray-500">
                          <Clock size={12} className="mr-1" />
                          {Math.ceil((new Date(activity.date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} hari lagi
                        </div>
                      </div>
                    </div>
                  );
                })}
                {upcomingActivities.length > 5 && (
                  <p className="text-sm text-gray-500 text-center">
                    +{upcomingActivities.length - 5} kegiatan lainnya
                  </p>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar size={48} className="mx-auto text-gray-400 mb-2" />
                <p className="text-gray-500">Tidak ada kegiatan mendatang</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <CheckCircle className="mr-2 h-5 w-5 text-green-600" />
              Progres Kehadiran Anggota
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Rata-rata Kehadiran</span>
                <span className="text-lg font-bold text-green-600">
                  {attendanceProgress.attendanceRate}%
                </span>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-green-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${attendanceProgress.attendanceRate}%` }}
                ></div>
              </div>

              <div className="grid grid-cols-2 gap-3 mt-4">
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="flex items-center justify-center mb-1">
                    <UserCheck size={16} className="text-green-600 mr-1" />
                    <div className="text-lg font-bold text-green-600">
                      {attendanceProgress.detailedStats.hadir}
                    </div>
                  </div>
                  <p className="text-xs text-green-600">Rata-rata Hadir</p>
                </div>
                <div className="text-center p-3 bg-yellow-50 rounded-lg">
                  <div className="flex items-center justify-center mb-1">
                    <UserMinus size={16} className="text-yellow-600 mr-1" />
                    <div className="text-lg font-bold text-yellow-600">
                      {attendanceProgress.detailedStats.izin}
                    </div>
                  </div>
                  <p className="text-xs text-yellow-600">Rata-rata Izin</p>
                </div>
                <div className="text-center p-3 bg-red-50 rounded-lg">
                  <div className="flex items-center justify-center mb-1">
                    <UserX size={16} className="text-red-600 mr-1" />
                    <div className="text-lg font-bold text-red-600">
                      {attendanceProgress.detailedStats.sakit}
                    </div>
                  </div>
                  <p className="text-xs text-red-600">Rata-rata Sakit</p>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-center mb-1">
                    <UserX size={16} className="text-gray-600 mr-1" />
                    <div className="text-lg font-bold text-gray-600">
                      {attendanceProgress.detailedStats.alfa}
                    </div>
                  </div>
                  <p className="text-xs text-gray-600">Rata-rata Alfa</p>
                </div>
              </div>

              <div className="text-center p-3 bg-purple-50 rounded-lg">
                <div className="text-lg font-bold text-purple-600">
                  {attendanceProgress.totalActivitiesWithAttendance}
                </div>
                <p className="text-xs text-purple-600">Kegiatan dengan Absensi</p>
              </div>

              {recentActivities.length > 0 && (
                <div className="mt-4">
                  <h5 className="text-sm font-medium text-gray-700 mb-2">Kegiatan Terbaru:</h5>
                  <div className="space-y-2">
                    {recentActivities.slice(0, 3).map((activity) => {
                      const attendanceRate = getActivityAttendanceRate(activity);
                      return (
                        <div key={activity.id} className="flex items-center justify-between text-xs">
                          <span className="truncate flex-1">{activity.title}</span>
                          <div className="flex items-center ml-2">
                            <CheckCircle size={12} className="text-green-500 mr-1" />
                            <span className="text-gray-500">
                              {new Date(activity.date).toLocaleDateString('id-ID', { 
                                day: 'numeric', 
                                month: 'short' 
                              })}
                            </span>
                            {attendanceRate !== null && (
                              <span className="text-green-600 ml-2 font-medium">
                                {attendanceRate}%
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {stats.totalMembers === 0 && (
                <div className="text-center py-4">
                  <AlertCircle size={32} className="mx-auto text-gray-400 mb-2" />
                  <p className="text-sm text-gray-500">
                    Tambahkan anggota untuk melihat progres kehadiran
                  </p>
                </div>
              )}

              {stats.totalMembers > 0 && attendanceProgress.totalActivitiesWithAttendance === 0 && (
                <div className="text-center py-4">
                  <AlertCircle size={32} className="mx-auto text-gray-400 mb-2" />
                  <p className="text-sm text-gray-500">
                    Belum ada kegiatan dengan data absensi
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
