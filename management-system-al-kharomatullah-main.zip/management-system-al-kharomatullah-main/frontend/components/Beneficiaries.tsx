import React, { useState } from 'react';
import { Plus, Edit, Trash2, Printer, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { BeneficiaryForm } from './forms/BeneficiaryForm';
import { useToast } from '@/components/ui/use-toast';

interface Beneficiary {
  id: string;
  name: string;
  address: string;
  description: string;
  status: 'Yatim' | 'Piatu' | 'Dhuafa' | 'Lansia' | 'Janda' | 'Anggota' | 'Keluarga Anggota';
  nik?: string;
  ktpFile?: string;
  kkFile?: string;
  category: 'Bantuan Sosial' | 'Bantuan Kesehatan' | 'Bantuan Pendidikan' | 'Bantuan Ekonomi' | 'Bantuan Bencana' | 'Lainnya';
  createdAt: string;
}

export function Beneficiaries() {
  const [beneficiaries, setBeneficiaries] = useLocalStorage<Beneficiary[]>('beneficiaries', []);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingBeneficiary, setEditingBeneficiary] = useState<Beneficiary | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();

  const filteredBeneficiaries = beneficiaries.filter(beneficiary =>
    beneficiary.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    beneficiary.status.toLowerCase().includes(searchTerm.toLowerCase()) ||
    beneficiary.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSave = (beneficiaryData: Omit<Beneficiary, 'id' | 'createdAt'>) => {
    if (editingBeneficiary) {
      const updatedBeneficiaries = beneficiaries.map(beneficiary =>
        beneficiary.id === editingBeneficiary.id
          ? { ...beneficiaryData, id: editingBeneficiary.id, createdAt: editingBeneficiary.createdAt }
          : beneficiary
      );
      setBeneficiaries(updatedBeneficiaries);
      toast({
        title: "Berhasil",
        description: "Data penerima manfaat berhasil diperbarui",
      });
    } else {
      const newBeneficiary: Beneficiary = {
        ...beneficiaryData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      };
      setBeneficiaries([...beneficiaries, newBeneficiary]);
      toast({
        title: "Berhasil",
        description: "Penerima manfaat baru berhasil ditambahkan",
      });
    }
    setIsFormOpen(false);
    setEditingBeneficiary(null);
  };

  const handleEdit = (beneficiary: Beneficiary) => {
    setEditingBeneficiary(beneficiary);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus data penerima manfaat ini?')) {
      setBeneficiaries(beneficiaries.filter(beneficiary => beneficiary.id !== id));
      toast({
        title: "Berhasil",
        description: "Data penerima manfaat berhasil dihapus",
      });
    }
  };

  const handlePrint = () => {
    const printContent = `
      <html>
        <head>
          <title>Data Penerima Manfaat Al Kharomatullah</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { text-align: center; color: #166534; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .header { text-align: center; margin-bottom: 30px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Data Penerima Manfaat</h1>
            <h2>Management System Al Kharomatullah</h2>
            <p>Dicetak pada: ${new Date().toLocaleDateString('id-ID')}</p>
          </div>
          <table>
            <thead>
              <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Status</th>
                <th>Kategori Bantuan</th>
                <th>Alamat</th>
                <th>Keterangan</th>
              </tr>
            </thead>
            <tbody>
              ${filteredBeneficiaries.map((beneficiary, index) => `
                <tr>
                  <td>${index + 1}</td>
                  <td>${beneficiary.name}</td>
                  <td>${beneficiary.status}</td>
                  <td>${beneficiary.category}</td>
                  <td>${beneficiary.address}</td>
                  <td>${beneficiary.description}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const getStatusBadgeColor = (status: string) => {
    const colors = {
      'Yatim': 'bg-blue-100 text-blue-800',
      'Piatu': 'bg-purple-100 text-purple-800',
      'Dhuafa': 'bg-orange-100 text-orange-800',
      'Lansia': 'bg-gray-100 text-gray-800',
      'Janda': 'bg-pink-100 text-pink-800',
      'Anggota': 'bg-green-100 text-green-800',
      'Keluarga Anggota': 'bg-teal-100 text-teal-800',
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold text-gray-900">Data Penerima Manfaat</h1>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button onClick={handlePrint} variant="outline" className="flex items-center gap-2">
            <Printer size={16} />
            Cetak Data
          </Button>
          <Button onClick={() => setIsFormOpen(true)} className="flex items-center gap-2">
            <Plus size={16} />
            Tambah Penerima Manfaat
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Daftar Penerima Manfaat</CardTitle>
          <div className="flex items-center gap-2">
            <Search size={16} className="text-gray-400" />
            <Input
              placeholder="Cari nama, status, atau kategori..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Nama</th>
                  <th className="text-left p-2">Status</th>
                  <th className="text-left p-2">Kategori Bantuan</th>
                  <th className="text-left p-2">Alamat</th>
                  <th className="text-left p-2">Keterangan</th>
                  <th className="text-left p-2">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filteredBeneficiaries.map((beneficiary) => (
                  <tr key={beneficiary.id} className="border-b hover:bg-gray-50">
                    <td className="p-2 font-medium">{beneficiary.name}</td>
                    <td className="p-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadgeColor(beneficiary.status)}`}>
                        {beneficiary.status}
                      </span>
                    </td>
                    <td className="p-2">{beneficiary.category}</td>
                    <td className="p-2 max-w-xs truncate">{beneficiary.address}</td>
                    <td className="p-2 max-w-xs truncate">{beneficiary.description}</td>
                    <td className="p-2">
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(beneficiary)}
                          className="p-1"
                        >
                          <Edit size={14} />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDelete(beneficiary.id)}
                          className="p-1 text-red-600 hover:text-red-700"
                        >
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredBeneficiaries.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                {searchTerm ? 'Tidak ada penerima manfaat yang ditemukan' : 'Belum ada data penerima manfaat'}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {isFormOpen && (
        <BeneficiaryForm
          beneficiary={editingBeneficiary}
          onSave={handleSave}
          onCancel={() => {
            setIsFormOpen(false);
            setEditingBeneficiary(null);
          }}
        />
      )}
    </div>
  );
}
