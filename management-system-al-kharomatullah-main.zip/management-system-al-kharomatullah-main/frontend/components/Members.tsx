import React, { useState } from 'react';
import { Plus, Edit, Trash2, MessageCircle, Printer, Search, User, Phone, MapPin, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { MemberForm } from './forms/MemberForm';
import { useToast } from '@/components/ui/use-toast';

interface Member {
  id: string;
  name: string;
  nik: string;
  gender: 'Laki-laki' | 'Perempuan';
  birthDate: string;
  address: string;
  whatsapp: string;
  photo?: string;
  createdAt: string;
}

export function Members() {
  const [members, setMembers] = useLocalStorage<Member[]>('members', []);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const { toast } = useToast();

  const filteredMembers = members.filter(member =>
    member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.nik.includes(searchTerm) ||
    member.whatsapp.includes(searchTerm)
  );

  const handleSave = (memberData: Omit<Member, 'id' | 'createdAt'>) => {
    if (editingMember) {
      const updatedMembers = members.map(member =>
        member.id === editingMember.id
          ? { ...memberData, id: editingMember.id, createdAt: editingMember.createdAt }
          : member
      );
      setMembers(updatedMembers);
      toast({
        title: "Berhasil",
        description: "Data anggota berhasil diperbarui",
      });
    } else {
      const newMember: Member = {
        ...memberData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      };
      setMembers([...members, newMember]);
      toast({
        title: "Berhasil",
        description: "Anggota baru berhasil ditambahkan",
      });
    }
    setIsFormOpen(false);
    setEditingMember(null);
  };

  const handleEdit = (member: Member) => {
    setEditingMember(member);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus anggota ini?')) {
      setMembers(members.filter(member => member.id !== id));
      toast({
        title: "Berhasil",
        description: "Anggota berhasil dihapus",
      });
    }
  };

  const handleWhatsApp = (whatsapp: string, name: string) => {
    const formattedNumber = whatsapp.startsWith('62') ? whatsapp : `62${whatsapp.replace(/^0/, '')}`;
    const message = `Assalamu'alaikum ${name}, semoga sehat selalu.`;
    const url = `https://wa.me/${formattedNumber}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const handlePrint = () => {
    const printContent = `
      <html>
        <head>
          <title>Data Anggota Al Kharomatullah</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { text-align: center; color: #166534; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .header { text-align: center; margin-bottom: 30px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Data Anggota</h1>
            <h2>Management System Al Kharomatullah</h2>
            <p>Dicetak pada: ${new Date().toLocaleDateString('id-ID')}</p>
          </div>
          <table>
            <thead>
              <tr>
                <th>No</th>
                <th>Nama</th>
                <th>NIK</th>
                <th>Jenis Kelamin</th>
                <th>Tanggal Lahir</th>
                <th>Alamat</th>
                <th>WhatsApp</th>
              </tr>
            </thead>
            <tbody>
              ${filteredMembers.map((member, index) => `
                <tr>
                  <td>${index + 1}</td>
                  <td>${member.name}</td>
                  <td>${member.nik}</td>
                  <td>${member.gender}</td>
                  <td>${new Date(member.birthDate).toLocaleDateString('id-ID')}</td>
                  <td>${member.address}</td>
                  <td>${member.whatsapp}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const calculateAge = (birthDate: string) => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    
    return age;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold text-gray-900">Data Anggota</h1>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button onClick={handlePrint} variant="outline" className="flex items-center gap-2">
            <Printer size={16} />
            Cetak Data
          </Button>
          <Button onClick={() => setIsFormOpen(true)} className="flex items-center gap-2">
            <Plus size={16} />
            Tambah Anggota
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle>Daftar Anggota ({filteredMembers.length})</CardTitle>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Search size={16} className="text-gray-400" />
                <Input
                  placeholder="Cari nama, NIK, atau WhatsApp..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="max-w-sm"
                />
              </div>
              <div className="flex gap-1">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                >
                  Grid
                </Button>
                <Button
                  variant={viewMode === 'table' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('table')}
                >
                  Tabel
                </Button>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredMembers.map((member) => (
                <Card key={member.id} className="hover:shadow-lg transition-shadow duration-200">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0">
                        {member.photo ? (
                          <img
                            src={member.photo}
                            alt={member.name}
                            className="w-16 h-16 rounded-full object-cover border-2 border-gray-200"
                          />
                        ) : (
                          <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center border-2 border-gray-200">
                            <span className="text-white text-xl font-bold">
                              {member.name.charAt(0).toUpperCase()}
                            </span>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h3 className="text-lg font-semibold text-gray-900 truncate">
                          {member.name}
                        </h3>
                        <div className="flex items-center gap-1 text-sm text-gray-600 mt-1">
                          <User size={14} />
                          <span>{member.gender}</span>
                          <span className="mx-1">•</span>
                          <span>{calculateAge(member.birthDate)} tahun</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 space-y-3">
                      <div className="flex items-start gap-2 text-sm">
                        <MapPin size={14} className="text-gray-400 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-600 line-clamp-2">{member.address}</span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm">
                        <Phone size={14} className="text-gray-400" />
                        <span className="text-gray-600">{member.whatsapp}</span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar size={14} className="text-gray-400" />
                        <span className="text-gray-600">
                          {new Date(member.birthDate).toLocaleDateString('id-ID', {
                            day: 'numeric',
                            month: 'long',
                            year: 'numeric'
                          })}
                        </span>
                      </div>
                    </div>

                    <div className="mt-4 pt-4 border-t border-gray-100">
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleWhatsApp(member.whatsapp, member.name)}
                          className="flex-1 text-green-600 hover:text-green-700 hover:bg-green-50"
                        >
                          <MessageCircle size={14} className="mr-1" />
                          WhatsApp
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(member)}
                          className="px-3"
                        >
                          <Edit size={14} />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDelete(member.id)}
                          className="px-3 text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </div>

                    <div className="mt-3 text-xs text-gray-400">
                      NIK: {member.nik}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2">Foto</th>
                    <th className="text-left p-2">Nama</th>
                    <th className="text-left p-2">NIK</th>
                    <th className="text-left p-2">Jenis Kelamin</th>
                    <th className="text-left p-2">Tanggal Lahir</th>
                    <th className="text-left p-2">WhatsApp</th>
                    <th className="text-left p-2">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredMembers.map((member) => (
                    <tr key={member.id} className="border-b hover:bg-gray-50">
                      <td className="p-2">
                        {member.photo ? (
                          <img
                            src={member.photo}
                            alt={member.name}
                            className="w-10 h-10 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                            <span className="text-gray-500 text-sm">
                              {member.name.charAt(0).toUpperCase()}
                            </span>
                          </div>
                        )}
                      </td>
                      <td className="p-2 font-medium">{member.name}</td>
                      <td className="p-2">{member.nik}</td>
                      <td className="p-2">{member.gender}</td>
                      <td className="p-2">{new Date(member.birthDate).toLocaleDateString('id-ID')}</td>
                      <td className="p-2">{member.whatsapp}</td>
                      <td className="p-2">
                        <div className="flex gap-1">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleWhatsApp(member.whatsapp, member.name)}
                            className="p-1"
                          >
                            <MessageCircle size={14} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(member)}
                            className="p-1"
                          >
                            <Edit size={14} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDelete(member.id)}
                            className="p-1 text-red-600 hover:text-red-700"
                          >
                            <Trash2 size={14} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          
          {filteredMembers.length === 0 && (
            <div className="text-center py-12">
              <User size={48} className="mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {searchTerm ? 'Tidak ada anggota yang ditemukan' : 'Belum ada data anggota'}
              </h3>
              <p className="text-gray-500 mb-4">
                {searchTerm ? 'Coba ubah kata kunci pencarian' : 'Tambahkan anggota pertama Anda'}
              </p>
              {!searchTerm && (
                <Button onClick={() => setIsFormOpen(true)} className="flex items-center gap-2">
                  <Plus size={16} />
                  Tambah Anggota
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {isFormOpen && (
        <MemberForm
          member={editingMember}
          onSave={handleSave}
          onCancel={() => {
            setIsFormOpen(false);
            setEditingMember(null);
          }}
        />
      )}
    </div>
  );
}
