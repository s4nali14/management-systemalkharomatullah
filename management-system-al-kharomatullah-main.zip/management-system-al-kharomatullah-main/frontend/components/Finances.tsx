import React, { useState } from 'react';
import { Plus, Edit, Trash2, Printer, Search, MessageCircle, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { FinanceForm } from './forms/FinanceForm';
import { useToast } from '@/components/ui/use-toast';

interface Finance {
  id: string;
  date: string;
  type: 'Pemasukan' | 'Pengeluaran';
  amount: number;
  description: string;
  source: 'Saldo Awal' | 'Dana Santunan' | 'Dana Baksos Pengobatan' | 'Dana Sosial' | 'Zakat' | 'Infaq' | 'Iuran Anggota' | 'Lainnya';
  createdAt: string;
}

interface Member {
  id: string;
  name: string;
  whatsapp: string;
}

export function Finances() {
  const [finances, setFinances] = useLocalStorage<Finance[]>('finances', []);
  const [members] = useLocalStorage<Member[]>('members', []);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingFinance, setEditingFinance] = useState<Finance | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMonth, setFilterMonth] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterSource, setFilterSource] = useState('');
  const { toast } = useToast();

  const filteredFinances = finances.filter(finance => {
    const matchesSearch = finance.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         finance.source.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesMonth = !filterMonth || finance.date.startsWith(filterMonth);
    const matchesType = !filterType || finance.type === filterType;
    const matchesSource = !filterSource || finance.source === filterSource;
    
    return matchesSearch && matchesMonth && matchesType && matchesSource;
  });

  const totalIncome = filteredFinances
    .filter(f => f.type === 'Pemasukan')
    .reduce((sum, f) => sum + f.amount, 0);

  const totalExpense = filteredFinances
    .filter(f => f.type === 'Pengeluaran')
    .reduce((sum, f) => sum + f.amount, 0);

  const balance = totalIncome - totalExpense;

  // Calculate income by source
  const incomeBySource = finances
    .filter(f => f.type === 'Pemasukan')
    .reduce((acc, f) => {
      acc[f.source] = (acc[f.source] || 0) + f.amount;
      return acc;
    }, {} as Record<string, number>);

  const handleSave = (financeData: Omit<Finance, 'id' | 'createdAt'>) => {
    if (editingFinance) {
      const updatedFinances = finances.map(finance =>
        finance.id === editingFinance.id
          ? { ...financeData, id: editingFinance.id, createdAt: editingFinance.createdAt }
          : finance
      );
      setFinances(updatedFinances);
      toast({
        title: "Berhasil",
        description: "Data keuangan berhasil diperbarui",
      });
    } else {
      const newFinance: Finance = {
        ...financeData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      };
      setFinances([...finances, newFinance]);
      toast({
        title: "Berhasil",
        description: "Data keuangan baru berhasil ditambahkan",
      });
    }
    setIsFormOpen(false);
    setEditingFinance(null);
  };

  const handleEdit = (finance: Finance) => {
    setEditingFinance(finance);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus data keuangan ini?')) {
      setFinances(finances.filter(finance => finance.id !== id));
      toast({
        title: "Berhasil",
        description: "Data keuangan berhasil dihapus",
      });
    }
  };

  const handlePrint = () => {
    const printContent = `
      <html>
        <head>
          <title>Laporan Keuangan Al Kharomatullah</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { text-align: center; color: #166534; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .header { text-align: center; margin-bottom: 30px; }
            .summary { margin: 20px 0; padding: 15px; background-color: #f9f9f9; border-radius: 5px; }
            .income { color: #16a34a; }
            .expense { color: #dc2626; }
            .balance { color: ${balance >= 0 ? '#16a34a' : '#dc2626'}; font-weight: bold; }
            .income-breakdown { margin: 20px 0; padding: 15px; background-color: #f0f9ff; border-radius: 5px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Laporan Keuangan</h1>
            <h2>Management System Al Kharomatullah</h2>
            <p>Dicetak pada: ${new Date().toLocaleDateString('id-ID')}</p>
          </div>
          
          <div class="summary">
            <h3>Ringkasan Keuangan</h3>
            <p class="income">Total Pemasukan: ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(totalIncome)}</p>
            <p class="expense">Total Pengeluaran: ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(totalExpense)}</p>
            <p class="balance">Saldo: ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(balance)}</p>
          </div>

          <div class="income-breakdown">
            <h3>Rincian Pemasukan per Sumber</h3>
            ${Object.entries(incomeBySource).map(([source, amount]) => `
              <p><strong>${source}:</strong> ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(amount)}</p>
            `).join('')}
          </div>
          
          <table>
            <thead>
              <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Jenis</th>
                <th>Jumlah</th>
                <th>Sumber/Kategori</th>
                <th>Keterangan</th>
              </tr>
            </thead>
            <tbody>
              ${filteredFinances.map((finance, index) => `
                <tr>
                  <td>${index + 1}</td>
                  <td>${new Date(finance.date).toLocaleDateString('id-ID')}</td>
                  <td>${finance.type}</td>
                  <td class="${finance.type === 'Pemasukan' ? 'income' : 'expense'}">
                    ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(finance.amount)}
                  </td>
                  <td>${finance.source}</td>
                  <td>${finance.description}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const handleSendWhatsAppNotification = () => {
    const currentMonth = new Date().toISOString().slice(0, 7);
    const monthlyPayments = finances.filter(f => 
      f.type === 'Pemasukan' && 
      f.source === 'Iuran Anggota' && 
      f.date.startsWith(currentMonth)
    );
    
    const paidMembers = new Set(
      monthlyPayments.map(payment => 
        payment.description.toLowerCase().includes('iuran') ? 
        payment.description.split(' ')[0] : ''
      ).filter(Boolean)
    );

    const unpaidMembers = members.filter(member => 
      !paidMembers.has(member.name.toLowerCase())
    );

    if (unpaidMembers.length === 0) {
      toast({
        title: "Info",
        description: "Semua anggota sudah membayar iuran bulan ini",
      });
      return;
    }

    const monthName = new Date().toLocaleDateString('id-ID', { month: 'long', year: 'numeric' });
    const message = `Assalamu'alaikum. Reminder iuran bulanan ${monthName}. Jazakallahu khairan.`;

    unpaidMembers.forEach(member => {
      const formattedNumber = member.whatsapp.startsWith('62') ? member.whatsapp : `62${member.whatsapp.replace(/^0/, '')}`;
      const url = `https://wa.me/${formattedNumber}?text=${encodeURIComponent(message)}`;
      window.open(url, '_blank');
    });

    toast({
      title: "Berhasil",
      description: `Notifikasi WhatsApp dikirim ke ${unpaidMembers.length} anggota`,
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
    }).format(amount);
  };

  const getSourceColor = (source: string) => {
    const colors = {
      'Saldo Awal': 'bg-purple-100 text-purple-800',
      'Dana Santunan': 'bg-blue-100 text-blue-800',
      'Dana Baksos Pengobatan': 'bg-green-100 text-green-800',
      'Dana Sosial': 'bg-orange-100 text-orange-800',
      'Zakat': 'bg-teal-100 text-teal-800',
      'Infaq': 'bg-pink-100 text-pink-800',
      'Iuran Anggota': 'bg-indigo-100 text-indigo-800',
      'Operasional': 'bg-gray-100 text-gray-800',
      'Lainnya': 'bg-yellow-100 text-yellow-800',
    };
    return colors[source as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold text-gray-900">Laporan Keuangan</h1>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button 
            onClick={handleSendWhatsAppNotification} 
            variant="outline" 
            className="flex items-center gap-2"
          >
            <MessageCircle size={16} />
            Kirim Notifikasi WA
          </Button>
          <Button onClick={handlePrint} variant="outline" className="flex items-center gap-2">
            <Printer size={16} />
            Cetak Laporan
          </Button>
          <Button onClick={() => setIsFormOpen(true)} className="flex items-center gap-2">
            <Plus size={16} />
            Tambah Transaksi
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-green-600">Total Pemasukan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {formatCurrency(totalIncome)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-red-600">Total Pengeluaran</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {formatCurrency(totalExpense)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className={balance >= 0 ? 'text-green-600' : 'text-red-600'}>Saldo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(balance)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Income Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Rincian Pemasukan per Sumber</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.entries(incomeBySource).map(([source, amount]) => (
              <div key={source} className="p-4 bg-gray-50 rounded-lg">
                <div className="text-sm text-gray-600 mb-1">{source}</div>
                <div className="text-lg font-bold text-green-600">
                  {formatCurrency(amount)}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Daftar Transaksi</CardTitle>
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="flex items-center gap-2">
              <Search size={16} className="text-gray-400" />
              <Input
                placeholder="Cari keterangan atau sumber..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-sm"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter size={16} className="text-gray-400" />
              <Input
                type="month"
                value={filterMonth}
                onChange={(e) => setFilterMonth(e.target.value)}
                className="max-w-sm"
              />
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="max-w-sm">
                  <SelectValue placeholder="Semua Jenis" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Jenis</SelectItem>
                  <SelectItem value="Pemasukan">Pemasukan</SelectItem>
                  <SelectItem value="Pengeluaran">Pengeluaran</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterSource} onValueChange={setFilterSource}>
                <SelectTrigger className="max-w-sm">
                  <SelectValue placeholder="Semua Sumber" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Sumber</SelectItem>
                  <SelectItem value="Saldo Awal">Saldo Awal</SelectItem>
                  <SelectItem value="Dana Santunan">Dana Santunan</SelectItem>
                  <SelectItem value="Dana Baksos Pengobatan">Dana Baksos Pengobatan</SelectItem>
                  <SelectItem value="Dana Sosial">Dana Sosial</SelectItem>
                  <SelectItem value="Zakat">Zakat</SelectItem>
                  <SelectItem value="Infaq">Infaq</SelectItem>
                  <SelectItem value="Iuran Anggota">Iuran Anggota</SelectItem>
                  <SelectItem value="Operasional">Operasional</SelectItem>
                  <SelectItem value="Lainnya">Lainnya</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Tanggal</th>
                  <th className="text-left p-2">Jenis</th>
                  <th className="text-left p-2">Jumlah</th>
                  <th className="text-left p-2">Sumber/Kategori</th>
                  <th className="text-left p-2">Keterangan</th>
                  <th className="text-left p-2">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filteredFinances.map((finance) => (
                  <tr key={finance.id} className="border-b hover:bg-gray-50">
                    <td className="p-2">{new Date(finance.date).toLocaleDateString('id-ID')}</td>
                    <td className="p-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        finance.type === 'Pemasukan' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {finance.type}
                      </span>
                    </td>
                    <td className={`p-2 font-medium ${
                      finance.type === 'Pemasukan' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {formatCurrency(finance.amount)}
                    </td>
                    <td className="p-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSourceColor(finance.source)}`}>
                        {finance.source}
                      </span>
                    </td>
                    <td className="p-2 max-w-xs truncate">{finance.description}</td>
                    <td className="p-2">
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(finance)}
                          className="p-1"
                        >
                          <Edit size={14} />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDelete(finance.id)}
                          className="p-1 text-red-600 hover:text-red-700"
                        >
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredFinances.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                {searchTerm || filterMonth || filterType || filterSource ? 'Tidak ada transaksi yang ditemukan' : 'Belum ada data transaksi'}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {isFormOpen && (
        <FinanceForm
          finance={editingFinance}
          onSave={handleSave}
          onCancel={() => {
            setIsFormOpen(false);
            setEditingFinance(null);
          }}
        />
      )}
    </div>
  );
}
