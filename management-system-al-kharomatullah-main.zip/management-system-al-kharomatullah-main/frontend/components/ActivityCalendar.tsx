import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface Activity {
  id: string;
  title: string;
  date: string;
  type: string;
  description: string;
  responsible?: string;
  file?: string;
  createdAt: string;
}

interface ActivityCalendarProps {
  activities: Activity[];
  onEditActivity: (activity: Activity) => void;
  onDeleteActivity: (id: string) => void;
}

export function ActivityCalendar({ activities, onEditActivity, onDeleteActivity }: ActivityCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());

  const monthNames = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];

  const dayNames = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(day);
    }
    
    return days;
  };

  const getActivitiesForDate = (day: number) => {
    if (!day) return [];
    
    const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return activities.filter(activity => activity.date === dateStr);
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  const days = getDaysInMonth(currentDate);

  const getTypeColor = (type: string) => {
    const colors = {
      'Bakti Sosial Pengobatan': 'bg-blue-500',
      'Bantuan Sosial/Bencana': 'bg-red-500',
      'Santunan': 'bg-green-500',
      'Pertemuan Bulanan': 'bg-purple-500',
      'Kajian': 'bg-orange-500',
      'Pendalaman Materi': 'bg-teal-500',
      'Rapat': 'bg-gray-500',
    };
    return colors[type as keyof typeof colors] || 'bg-gray-500';
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-4">
            <Button variant="outline" size="sm" onClick={() => navigateMonth('prev')}>
              <ChevronLeft size={16} />
            </Button>
            <span className="text-xl font-bold">
              {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
            </span>
            <Button variant="outline" size="sm" onClick={() => navigateMonth('next')}>
              <ChevronRight size={16} />
            </Button>
          </CardTitle>
          <Button variant="outline" size="sm" onClick={goToToday}>
            Hari Ini
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-7 gap-1 mb-4">
          {dayNames.map(day => (
            <div key={day} className="p-2 text-center font-medium text-gray-600 bg-gray-50 rounded">
              {day}
            </div>
          ))}
        </div>
        
        <div className="grid grid-cols-7 gap-1">
          {days.map((day, index) => {
            const dayActivities = day ? getActivitiesForDate(day) : [];
            const isToday = day && 
              currentDate.getFullYear() === new Date().getFullYear() &&
              currentDate.getMonth() === new Date().getMonth() &&
              day === new Date().getDate();
            
            return (
              <div
                key={index}
                className={`min-h-[100px] p-1 border rounded ${
                  day ? 'bg-white hover:bg-gray-50' : 'bg-gray-100'
                } ${isToday ? 'ring-2 ring-blue-500' : ''}`}
              >
                {day && (
                  <>
                    <div className={`text-sm font-medium mb-1 ${isToday ? 'text-blue-600' : 'text-gray-900'}`}>
                      {day}
                    </div>
                    <div className="space-y-1">
                      {dayActivities.map(activity => (
                        <div
                          key={activity.id}
                          className={`text-xs p-1 rounded text-white ${getTypeColor(activity.type)} group relative`}
                        >
                          <div className="truncate">{activity.title}</div>
                          <div className="hidden group-hover:flex absolute top-0 right-0 bg-white border rounded shadow-lg p-2 z-10 min-w-[200px]">
                            <div className="text-gray-900 text-sm">
                              <div className="font-medium">{activity.title}</div>
                              <div className="text-xs text-gray-600 mt-1">{activity.type}</div>
                              {activity.responsible && (
                                <div className="text-xs text-gray-600">PJ: {activity.responsible}</div>
                              )}
                              <div className="text-xs text-gray-600 mt-1">{activity.description}</div>
                              <div className="flex gap-1 mt-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => onEditActivity(activity)}
                                  className="p-1 h-6"
                                >
                                  <Edit size={12} />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => onDeleteActivity(activity.id)}
                                  className="p-1 h-6 text-red-600 hover:text-red-700"
                                >
                                  <Trash2 size={12} />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
