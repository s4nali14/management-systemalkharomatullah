import React, { useState } from 'react';
import { Plus, Edit, Trash2, Printer, Calendar as CalendarIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { ActivityForm } from './forms/ActivityForm';
import { ActivityCalendar } from './ActivityCalendar';
import { useToast } from '@/components/ui/use-toast';

interface AttendanceRecord {
  memberId: string;
  memberName: string;
  status: 'Hadir' | 'Izin' | 'Sakit' | 'Alfa';
}

interface Activity {
  id: string;
  title: string;
  date: string;
  type: 'Bakti Sosial Pengobatan' | 'Bantuan Sosial/Bencana' | 'Santunan' | 'Pertemuan Bulanan' | 'Kajian' | 'Pendalaman Materi' | 'Rapat';
  description: string;
  responsible?: string;
  file?: string;
  attendance?: AttendanceRecord[];
  createdAt: string;
}

export function Activities() {
  const [activities, setActivities] = useLocalStorage<Activity[]>('activities', []);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);
  const [viewMode, setViewMode] = useState<'calendar' | 'list'>('calendar');
  const { toast } = useToast();

  const handleSave = (activityData: Omit<Activity, 'id' | 'createdAt'>) => {
    if (editingActivity) {
      const updatedActivities = activities.map(activity =>
        activity.id === editingActivity.id
          ? { ...activityData, id: editingActivity.id, createdAt: editingActivity.createdAt }
          : activity
      );
      setActivities(updatedActivities);
      toast({
        title: "Berhasil",
        description: "Kegiatan berhasil diperbarui",
      });
    } else {
      const newActivity: Activity = {
        ...activityData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      };
      setActivities([...activities, newActivity]);
      toast({
        title: "Berhasil",
        description: "Kegiatan baru berhasil ditambahkan",
      });
    }
    setIsFormOpen(false);
    setEditingActivity(null);
  };

  const handleEdit = (activity: Activity) => {
    setEditingActivity(activity);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus kegiatan ini?')) {
      setActivities(activities.filter(activity => activity.id !== id));
      toast({
        title: "Berhasil",
        description: "Kegiatan berhasil dihapus",
      });
    }
  };

  const handlePrint = () => {
    const printContent = `
      <html>
        <head>
          <title>Laporan Kegiatan Al Kharomatullah</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { text-align: center; color: #166534; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .header { text-align: center; margin-bottom: 30px; }
            .attendance-summary { margin: 10px 0; font-size: 12px; color: #666; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Laporan Kegiatan</h1>
            <h2>Management System Al Kharomatullah</h2>
            <p>Dicetak pada: ${new Date().toLocaleDateString('id-ID')}</p>
          </div>
          <table>
            <thead>
              <tr>
                <th>No</th>
                <th>Judul Kegiatan</th>
                <th>Tanggal</th>
                <th>Jenis Kegiatan</th>
                <th>Penanggung Jawab</th>
                <th>Kehadiran</th>
                <th>Deskripsi</th>
              </tr>
            </thead>
            <tbody>
              ${activities.map((activity, index) => {
                const attendanceStats = activity.attendance ? {
                  hadir: activity.attendance.filter(a => a.status === 'Hadir').length,
                  izin: activity.attendance.filter(a => a.status === 'Izin').length,
                  sakit: activity.attendance.filter(a => a.status === 'Sakit').length,
                  alfa: activity.attendance.filter(a => a.status === 'Alfa').length,
                  total: activity.attendance.length
                } : null;
                
                return `
                <tr>
                  <td>${index + 1}</td>
                  <td>${activity.title}</td>
                  <td>${new Date(activity.date).toLocaleDateString('id-ID')}</td>
                  <td>${activity.type}</td>
                  <td>${activity.responsible || '-'}</td>
                  <td>${attendanceStats ? `Hadir: ${attendanceStats.hadir}, Izin: ${attendanceStats.izin}, Sakit: ${attendanceStats.sakit}, Alfa: ${attendanceStats.alfa} (Total: ${attendanceStats.total})` : '-'}</td>
                  <td>${activity.description}</td>
                </tr>
              `;
              }).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const getTypeColor = (type: string) => {
    const colors = {
      'Bakti Sosial Pengobatan': 'bg-blue-100 text-blue-800',
      'Bantuan Sosial/Bencana': 'bg-red-100 text-red-800',
      'Santunan': 'bg-green-100 text-green-800',
      'Pertemuan Bulanan': 'bg-purple-100 text-purple-800',
      'Kajian': 'bg-orange-100 text-orange-800',
      'Pendalaman Materi': 'bg-teal-100 text-teal-800',
      'Rapat': 'bg-gray-100 text-gray-800',
    };
    return colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const getAttendanceStats = (activity: Activity) => {
    if (!activity.attendance) return null;
    
    const hadir = activity.attendance.filter(a => a.status === 'Hadir').length;
    const total = activity.attendance.length;
    const percentage = total > 0 ? Math.round((hadir / total) * 100) : 0;
    
    return { hadir, total, percentage };
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold text-gray-900">Kalender Agenda Kegiatan</h1>
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="flex gap-2">
            <Button
              variant={viewMode === 'calendar' ? 'default' : 'outline'}
              onClick={() => setViewMode('calendar')}
              size="sm"
            >
              <CalendarIcon size={16} className="mr-1" />
              Kalender
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              onClick={() => setViewMode('list')}
              size="sm"
            >
              Daftar
            </Button>
          </div>
          <Button onClick={handlePrint} variant="outline" className="flex items-center gap-2">
            <Printer size={16} />
            Cetak Laporan
          </Button>
          <Button onClick={() => setIsFormOpen(true)} className="flex items-center gap-2">
            <Plus size={16} />
            Tambah Kegiatan
          </Button>
        </div>
      </div>

      {viewMode === 'calendar' ? (
        <ActivityCalendar
          activities={activities}
          onEditActivity={handleEdit}
          onDeleteActivity={handleDelete}
        />
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Daftar Kegiatan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2">Judul</th>
                    <th className="text-left p-2">Tanggal</th>
                    <th className="text-left p-2">Jenis</th>
                    <th className="text-left p-2">Penanggung Jawab</th>
                    <th className="text-left p-2">Kehadiran</th>
                    <th className="text-left p-2">Deskripsi</th>
                    <th className="text-left p-2">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {activities.map((activity) => {
                    const attendanceStats = getAttendanceStats(activity);
                    return (
                      <tr key={activity.id} className="border-b hover:bg-gray-50">
                        <td className="p-2 font-medium">{activity.title}</td>
                        <td className="p-2">{new Date(activity.date).toLocaleDateString('id-ID')}</td>
                        <td className="p-2">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(activity.type)}`}>
                            {activity.type}
                          </span>
                        </td>
                        <td className="p-2">{activity.responsible || '-'}</td>
                        <td className="p-2">
                          {attendanceStats ? (
                            <div className="text-sm">
                              <div className="flex items-center gap-2">
                                <span className="text-green-600 font-medium">{attendanceStats.percentage}%</span>
                                <span className="text-gray-500">({attendanceStats.hadir}/{attendanceStats.total})</span>
                              </div>
                            </div>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </td>
                        <td className="p-2 max-w-xs truncate">{activity.description}</td>
                        <td className="p-2">
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEdit(activity)}
                              className="p-1"
                            >
                              <Edit size={14} />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDelete(activity.id)}
                              className="p-1 text-red-600 hover:text-red-700"
                            >
                              <Trash2 size={14} />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {activities.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  Belum ada kegiatan yang dijadwalkan
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {isFormOpen && (
        <ActivityForm
          activity={editingActivity}
          onSave={handleSave}
          onCancel={() => {
            setIsFormOpen(false);
            setEditingActivity(null);
          }}
        />
      )}
    </div>
  );
}
