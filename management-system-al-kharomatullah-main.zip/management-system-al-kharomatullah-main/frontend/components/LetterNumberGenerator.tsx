import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { X, Copy } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface Letter {
  id: string;
  number: string;
  division: 'PEM' | 'KETEUM' | 'SEKRE' | 'HUMAS' | 'KOOR';
  type: 'SU' | 'SE' | 'SKPEM' | 'SK' | 'SPK' | 'SH' | 'SST' | 'SP' | 'SKK' | 'SI';
  createdAt: string;
}

interface LetterNumberGeneratorProps {
  letters: Letter[];
  onClose: () => void;
}

export function LetterNumberGenerator({ letters, onClose }: LetterNumberGeneratorProps) {
  const [division, setDivision] = useState<'PEM' | 'KETEUM' | 'SEKRE' | 'HUMAS' | 'KOOR'>('PEM');
  const [type, setType] = useState<'SU' | 'SE' | 'SKPEM' | 'SK' | 'SPK' | 'SH' | 'SST' | 'SP' | 'SKK' | 'SI'>('SU');
  const [generatedNumber, setGeneratedNumber] = useState('');
  const { toast } = useToast();

  const generateNumber = () => {
    const now = new Date();
    const month = now.getMonth() + 1;
    const year = now.getFullYear();
    
    const romanMonths = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];
    const romanMonth = romanMonths[month - 1];
    
    // Get the count of letters for this division and type in current month/year
    const count = letters.filter(letter => {
      const letterDate = new Date(letter.createdAt);
      return letter.division === division && 
             letter.type === type && 
             letterDate.getMonth() + 1 === month &&
             letterDate.getFullYear() === year;
    }).length;
    
    const nextNumber = count + 1;
    const paddedNumber = nextNumber.toString().padStart(3, '0');
    const letterNumber = `${paddedNumber}/${division}-${type}/${romanMonth}.${year}`;
    
    setGeneratedNumber(letterNumber);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedNumber);
    toast({
      title: "Berhasil",
      description: "Nomor surat berhasil disalin ke clipboard",
    });
  };

  const getDivisionName = (div: string) => {
    const names = {
      'PEM': 'Pembina',
      'KETEUM': 'Ketua Umum',
      'SEKRE': 'Sekretaris',
      'HUMAS': 'Humas',
      'KOOR': 'Koordinator',
    };
    return names[div as keyof typeof names] || div;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Generator Nomor Surat</CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X size={16} />
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Divisi</label>
            <Select value={division} onValueChange={(value: any) => setDivision(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="PEM">Pembina (PEM)</SelectItem>
                <SelectItem value="KETEUM">Ketua Umum (KETEUM)</SelectItem>
                <SelectItem value="SEKRE">Sekretaris (SEKRE)</SelectItem>
                <SelectItem value="HUMAS">Humas (HUMAS)</SelectItem>
                <SelectItem value="KOOR">Koordinator (KOOR)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Jenis Surat</label>
            <Select value={type} onValueChange={(value: any) => setType(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="SU">Surat Undangan (SU)</SelectItem>
                <SelectItem value="SE">Surat Edaran (SE)</SelectItem>
                <SelectItem value="SKPEM">Surat Keputusan Pembina (SKPEM)</SelectItem>
                <SelectItem value="SK">Surat Keputusan (SK)</SelectItem>
                <SelectItem value="SPK">Surat Perintah Kerja (SPK)</SelectItem>
                <SelectItem value="SH">Surat Himbauan (SH)</SelectItem>
                <SelectItem value="SST">Surat Serah Terima (SST)</SelectItem>
                <SelectItem value="SP">Surat Peringatan (SP)</SelectItem>
                <SelectItem value="SKK">Surat Keterangan Kerja (SKK)</SelectItem>
                <SelectItem value="SI">Surat Izin (SI)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button onClick={generateNumber} className="w-full">
            Generate Nomor Surat
          </Button>

          {generatedNumber && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Nomor Surat yang Dihasilkan</label>
              <div className="flex items-center gap-2">
                <div className="flex-1 p-2 bg-gray-50 rounded border font-mono text-sm">
                  {generatedNumber}
                </div>
                <Button size="sm" variant="outline" onClick={copyToClipboard}>
                  <Copy size={14} />
                </Button>
              </div>
              <p className="text-xs text-gray-600">
                Format: Nomor/Divisi-Jenis/Bulan(Romawi).Tahun
              </p>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={onClose}>
              Tutup
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
