import React, { useState } from 'react';
import { Plus, Edit, Trash2, Download, Search, Upload, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { DocumentForm } from './forms/DocumentForm';
import { useToast } from '@/components/ui/use-toast';

interface Document {
  id: string;
  name: string;
  description: string;
  fileName: string;
  fileSize: number;
  fileType: string;
  fileData: string;
  uploadDate: string;
  createdAt: string;
}

export function Documents() {
  const [documents, setDocuments] = useLocalStorage<Document[]>('documents', []);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingDocument, setEditingDocument] = useState<Document | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();

  const filteredDocuments = documents.filter(document =>
    document.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    document.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    document.fileName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSave = (documentData: Omit<Document, 'id' | 'createdAt'>) => {
    if (editingDocument) {
      const updatedDocuments = documents.map(document =>
        document.id === editingDocument.id
          ? { ...documentData, id: editingDocument.id, createdAt: editingDocument.createdAt }
          : document
      );
      setDocuments(updatedDocuments);
      toast({
        title: "Berhasil",
        description: "Dokumen berhasil diperbarui",
      });
    } else {
      const newDocument: Document = {
        ...documentData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      };
      setDocuments([...documents, newDocument]);
      toast({
        title: "Berhasil",
        description: "Dokumen baru berhasil ditambahkan",
      });
    }
    setIsFormOpen(false);
    setEditingDocument(null);
  };

  const handleEdit = (document: Document) => {
    setEditingDocument(document);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus dokumen ini?')) {
      setDocuments(documents.filter(document => document.id !== id));
      toast({
        title: "Berhasil",
        description: "Dokumen berhasil dihapus",
      });
    }
  };

  const handleDownload = (document: Document) => {
    try {
      const link = document.createElement('a');
      link.href = document.fileData;
      link.download = document.fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      toast({
        title: "Error",
        description: "Gagal mengunduh file",
        variant: "destructive",
      });
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) {
      return '🖼️';
    } else if (fileType.includes('pdf')) {
      return '📄';
    } else if (fileType.includes('word') || fileType.includes('document')) {
      return '📝';
    } else if (fileType.includes('excel') || fileType.includes('spreadsheet')) {
      return '📊';
    } else {
      return '📁';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold text-gray-900">Dokumen</h1>
        <Button onClick={() => setIsFormOpen(true)} className="flex items-center gap-2">
          <Plus size={16} />
          Upload Dokumen
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Daftar Dokumen</CardTitle>
          <div className="flex items-center gap-2">
            <Search size={16} className="text-gray-400" />
            <Input
              placeholder="Cari nama dokumen atau deskripsi..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDocuments.map((document) => (
              <Card key={document.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{getFileIcon(document.fileType)}</span>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium truncate">{document.name}</h3>
                        <p className="text-sm text-gray-500 truncate">{document.fileName}</p>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-3 line-clamp-2">{document.description}</p>
                  
                  <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                    <span>{formatFileSize(document.fileSize)}</span>
                    <span>{new Date(document.uploadDate).toLocaleDateString('id-ID')}</span>
                  </div>
                  
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDownload(document)}
                      className="flex-1"
                    >
                      <Download size={14} className="mr-1" />
                      Download
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(document)}
                      className="p-2"
                    >
                      <Edit size={14} />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDelete(document.id)}
                      className="p-2 text-red-600 hover:text-red-700"
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {filteredDocuments.length === 0 && (
            <div className="text-center py-12">
              <FileText size={48} className="mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {searchTerm ? 'Tidak ada dokumen yang ditemukan' : 'Belum ada dokumen'}
              </h3>
              <p className="text-gray-500 mb-4">
                {searchTerm ? 'Coba ubah kata kunci pencarian' : 'Upload dokumen pertama Anda'}
              </p>
              {!searchTerm && (
                <Button onClick={() => setIsFormOpen(true)} className="flex items-center gap-2">
                  <Upload size={16} />
                  Upload Dokumen
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {isFormOpen && (
        <DocumentForm
          document={editingDocument}
          onSave={handleSave}
          onCancel={() => {
            setIsFormOpen(false);
            setEditingDocument(null);
          }}
        />
      )}
    </div>
  );
}
