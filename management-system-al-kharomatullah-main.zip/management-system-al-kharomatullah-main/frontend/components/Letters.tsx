import React, { useState } from 'react';
import { Plus, Edit, Trash2, Download, Search, FileText, Hash } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { LetterForm } from './forms/LetterForm';
import { LetterNumberGenerator } from './LetterNumberGenerator';
import { useToast } from '@/components/ui/use-toast';

interface Letter {
  id: string;
  number: string;
  division: 'PEM' | 'KETEUM' | 'SEKRE' | 'HUMAS' | 'KOOR';
  type: 'SU' | 'SE' | 'SKPEM' | 'SK' | 'SPK' | 'SH' | 'SST' | 'SP' | 'SKK' | 'SI';
  title: string;
  description: string;
  file?: string;
  createdAt: string;
}

export function Letters() {
  const [letters, setLetters] = useLocalStorage<Letter[]>('letters', []);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isGeneratorOpen, setIsGeneratorOpen] = useState(false);
  const [editingLetter, setEditingLetter] = useState<Letter | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();

  const filteredLetters = letters.filter(letter =>
    letter.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    letter.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    letter.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSave = (letterData: Omit<Letter, 'id' | 'createdAt'>) => {
    if (editingLetter) {
      const updatedLetters = letters.map(letter =>
        letter.id === editingLetter.id
          ? { ...letterData, id: editingLetter.id, createdAt: editingLetter.createdAt }
          : letter
      );
      setLetters(updatedLetters);
      toast({
        title: "Berhasil",
        description: "Surat berhasil diperbarui",
      });
    } else {
      const newLetter: Letter = {
        ...letterData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      };
      setLetters([...letters, newLetter]);
      toast({
        title: "Berhasil",
        description: "Surat baru berhasil ditambahkan",
      });
    }
    setIsFormOpen(false);
    setEditingLetter(null);
  };

  const handleEdit = (letter: Letter) => {
    setEditingLetter(letter);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus surat ini?')) {
      setLetters(letters.filter(letter => letter.id !== id));
      toast({
        title: "Berhasil",
        description: "Surat berhasil dihapus",
      });
    }
  };

  const handleDownload = (letter: Letter) => {
    if (!letter.file) {
      toast({
        title: "Info",
        description: "Tidak ada file yang tersedia untuk diunduh",
      });
      return;
    }

    try {
      const link = document.createElement('a');
      link.href = letter.file;
      link.download = `${letter.number}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      toast({
        title: "Error",
        description: "Gagal mengunduh file",
        variant: "destructive",
      });
    }
  };

  const getDivisionName = (division: string) => {
    const names = {
      'PEM': 'Pembina',
      'KETEUM': 'Ketua Umum',
      'SEKRE': 'Sekretaris',
      'HUMAS': 'Humas',
      'KOOR': 'Koordinator',
    };
    return names[division as keyof typeof names] || division;
  };

  const getTypeColor = (type: string) => {
    const colors = {
      'SU': 'bg-blue-100 text-blue-800',
      'SE': 'bg-green-100 text-green-800',
      'SKPEM': 'bg-purple-100 text-purple-800',
      'SK': 'bg-orange-100 text-orange-800',
      'SPK': 'bg-red-100 text-red-800',
      'SH': 'bg-teal-100 text-teal-800',
      'SST': 'bg-pink-100 text-pink-800',
      'SP': 'bg-yellow-100 text-yellow-800',
      'SKK': 'bg-indigo-100 text-indigo-800',
      'SI': 'bg-gray-100 text-gray-800',
    };
    return colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold text-gray-900">Generator Nomor Surat</h1>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button onClick={() => setIsGeneratorOpen(true)} variant="outline" className="flex items-center gap-2">
            <Hash size={16} />
            Generate Nomor
          </Button>
          <Button onClick={() => setIsFormOpen(true)} className="flex items-center gap-2">
            <Plus size={16} />
            Tambah Surat
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Daftar Surat</CardTitle>
          <div className="flex items-center gap-2">
            <Search size={16} className="text-gray-400" />
            <Input
              placeholder="Cari nomor surat, judul, atau deskripsi..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Nomor Surat</th>
                  <th className="text-left p-2">Divisi</th>
                  <th className="text-left p-2">Jenis</th>
                  <th className="text-left p-2">Judul</th>
                  <th className="text-left p-2">Tanggal</th>
                  <th className="text-left p-2">File</th>
                  <th className="text-left p-2">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filteredLetters.map((letter) => (
                  <tr key={letter.id} className="border-b hover:bg-gray-50">
                    <td className="p-2 font-mono text-sm">{letter.number}</td>
                    <td className="p-2">{getDivisionName(letter.division)}</td>
                    <td className="p-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(letter.type)}`}>
                        {letter.type}
                      </span>
                    </td>
                    <td className="p-2 font-medium max-w-xs truncate">{letter.title}</td>
                    <td className="p-2">{new Date(letter.createdAt).toLocaleDateString('id-ID')}</td>
                    <td className="p-2">
                      {letter.file ? (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDownload(letter)}
                          className="p-1"
                        >
                          <Download size={14} />
                        </Button>
                      ) : (
                        <span className="text-gray-400 text-sm">-</span>
                      )}
                    </td>
                    <td className="p-2">
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(letter)}
                          className="p-1"
                        >
                          <Edit size={14} />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDelete(letter.id)}
                          className="p-1 text-red-600 hover:text-red-700"
                        >
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredLetters.length === 0 && (
              <div className="text-center py-12">
                <FileText size={48} className="mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  {searchTerm ? 'Tidak ada surat yang ditemukan' : 'Belum ada surat'}
                </h3>
                <p className="text-gray-500 mb-4">
                  {searchTerm ? 'Coba ubah kata kunci pencarian' : 'Buat surat pertama Anda'}
                </p>
                {!searchTerm && (
                  <Button onClick={() => setIsFormOpen(true)} className="flex items-center gap-2">
                    <Plus size={16} />
                    Tambah Surat
                  </Button>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {isGeneratorOpen && (
        <LetterNumberGenerator
          letters={letters}
          onClose={() => setIsGeneratorOpen(false)}
        />
      )}

      {isFormOpen && (
        <LetterForm
          letter={editingLetter}
          letters={letters}
          onSave={handleSave}
          onCancel={() => {
            setIsFormOpen(false);
            setEditingLetter(null);
          }}
        />
      )}
    </div>
  );
}
