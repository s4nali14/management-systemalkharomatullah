import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { Members } from './components/Members';
import { Beneficiaries } from './components/Beneficiaries';
import { Activities } from './components/Activities';
import { Finances } from './components/Finances';
import { Documents } from './components/Documents';
import { Letters } from './components/Letters';

export type Page = 'dashboard' | 'members' | 'beneficiaries' | 'activities' | 'finances' | 'documents' | 'letters';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />;
      case 'members':
        return <Members />;
      case 'beneficiaries':
        return <Beneficiaries />;
      case 'activities':
        return <Activities />;
      case 'finances':
        return <Finances />;
      case 'documents':
        return <Documents />;
      case 'letters':
        return <Letters />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar currentPage={currentPage} onPageChange={setCurrentPage} />
      <main className="flex-1 overflow-auto">
        <div className="p-6">
          {renderPage()}
        </div>
      </main>
    </div>
  );
}
